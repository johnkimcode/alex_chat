
alexchat_version=18.0
software_intro_title="Alex Chat - Telegram Chatting Script"
software_title="AlexChat v18.0.0"
software_version_pastebin_link="https://pastebin.com/raw/8Q5GkxT8"
software_pastebin_activation_link="https://pastebin.com/raw/vbYtC1cW"
software_update_message_pastebin_link="https://pastebin.com/raw/qX8tFA0x"
alex_software_update_download_pastebin_link="https://pastebin.com/raw/HB7dEVcM"
software_developer_contact="t.me/web_stop or @web_stop"
Decode_key_pastebin_link = "https://pastebin.com/raw/0i1CZcjT"


print("\nAlex Telegram Chats Loading....Please wait")
Saved_Members = []
import random
from telethon.tl.functions.channels import JoinChannelRequest
import os, sys, time
import requests
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.types import InputPeerChat
import asyncio
from telethon.sync import TelegramClient
from telethon import functions, types, utils
from telethon.errors.rpcerrorlist import YouBlockedUserError
from telethon.tl.types import ChannelParticipantAdmin, ChannelParticipantCreator, InputMessagesFilterPinned, InputPeerChannel, ChatBannedRights, MessageMediaPhoto, MessageMediaDocument, InputMediaDocument, InputPeerUser
import csv
import configparser
from telethon.errors import AuthKeyUnregisteredError, PhoneNumberBannedError, SessionPasswordNeededError, UserDeactivatedError
import json
import logging
import zipfile
import textwrap
import hashlib
import platform
from telethon.tl.functions.messages import GetHistoryRequest, GetMessagesRequest
from threading import Lock
from telethon import events
from asyncio import Queue
import datetime
from cryptography.fernet import Fernet
import threading
import re
from telethon.tl.types import ChannelParticipantsAdmins
from telethon.tl.functions.account import UpdateProfileRequest
import tempfile
import glob
from pathlib import Path
import httpcore
from telethon.tl.functions.updates import GetStateRequest
import sqlite3
from telethon.tl.functions.messages import GetDialogsRequest
from telethon.tl.types import InputPeerEmpty, UserStatusOffline, UserStatusRecently, UserStatusLastMonth, UserStatusLastWeek, PeerUser, PeerChannel
import shutil
from telethon.tl.functions.updates import GetDifferenceRequest
from dateutil import parser
from datetime import timedelta
import pandas as pd
from termcolor import colored
import colorama
from colorama import Fore, Back, Style
colorama.init(autoreset=True)
import subprocess
from csv import reader
import re
import httpcore

number_list=[]


processing=False




live_clone_bot_messages = 'Messages From Bots'
live_clone_admin_messages = 'Messages From Admins'
live_max_message_length = 'Max Message Length'
live_show_typing = 'Show Typing'
live_custom_bot_acc = 'Custom Bot Account'
live_custom_admin_acc = 'Custom Admin Account'
live_change_names = 'Match Account Names'
live_skip_msg_with_links = 'Skip Messages with Links'
live_replace_links_boolean = 'Replace All Links'
livecloner_new_replacement_link = 'Replacement Link'
live_replace_words = 'Replace Specific Words'
fakechat_universal_delay = 'Universal Delay Time (s)'

chat_scraper_number_of_messages = 'Number of Messages to scrap'
chat_scraper_min_delay = 'Min Delay Time (s)'
chat_scraper_max_delay  = 'Max Delay Time (s)'
chat_scraper_max_media_size = 'Max_Media_Size (MB)'
chat_scraper_scrap_sender_names = 'Scrap Sender Names and Profile'


maximum_group_links=6





 #GET DATE AND TIME
def get_internet_datetime(time_zone: str = "etc/utc") -> datetime:
    from datetime import datetime
    timeapi_url = "https://www.timeapi.io/api/Time/current/zone"
    headers = {
        "Accept": "application/json",
    }
    params = {"timeZone": time_zone}
    dt = None
    try:
        request = requests.get(timeapi_url, headers=headers, params=params)
        r_dict = request.json()
        dt = datetime(
            year=r_dict["year"],
            month=r_dict["month"],
            day=r_dict["day"],
            hour=r_dict["hour"],
            minute=r_dict["minute"],
            second=r_dict["seconds"],
            microsecond=r_dict["milliSeconds"] * 1000,
        )
    except Exception as e:
        logger.exception("ERROR getting datetime from internet..."+str(e))
        return None
    return dt

 
msg_post=None
url4msg = 'https://pastebin.com/raw/S72zFnJe' # url of paste
try:
    message_online = requests.get(url4msg) # response will be stored from url
    contenttttx = message_online.text  # raw text from url
    msg_post=str(contenttttx)
except:
    msg_post="All Telegram Marketing Scripts available @Web_Stop"


def print_section_title(text):

    # Function to get and close all running event loops

    def run_async_function():
        try:
            # Check if there's already an event loop running
            loop = asyncio.get_running_loop()
            # If a loop is already running, use it to run the coroutine
            print("Event loop is already running. Using the existing loop.")
            return loop.create_task(main_function())  # Use create_task to run the coroutine
        except:
            pass

    # Call the function
    run_async_function()

    try:
        os.system('cls')
    except:
        try:
            os.system('clear')
        except:
            pass


    print(Style.BRIGHT + Fore.GREEN+ '\n.................................')
    colors = ['red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']
    colored_text = ''.join(colored(char, color=random.choice(colors)) for char in text)
    print(colored_text)
    print(Style.BRIGHT + Fore.GREEN+ '.................................')
    print(Style.BRIGHT + Fore.MAGENTA+ msg_post)
    print(Style.BRIGHT + Fore.GREEN+ '.................................')

license_filepath = "app_data/License.txt"

if not os.path.exists(license_filepath):
        open(license_filepath,"w")


API_FILE="app_data/Telegram_API.txt"

if not os.path.exists(API_FILE):
        open(API_FILE,"w")


stored_entities = {}  


def load_settings(file_path):
    with open(file_path, 'r') as file:
        return json.load(file)

def get_value_by_key(settings_dict, key):
    return settings_dict.get(key, None)


if not os.path.exists(license_filepath):
    open(license_filepath,"w")

sessions_phone_file = 'phone.csv'
sessions_folder = './sessions'
profile_folder= './profiles'
profile_pictures_path = './profiles/profile_pictures'
bios_list_path = 'profiles/bios_list.csv'
names_list_path = 'profiles/names_list.csv'
usernames_list_path = 'profiles/username_list.csv'
saved_password_path = 'profiles/saved_2fa.csv'

listener_account_session_folder = 'saved_settings/live_cloner_settings/live_listener_phone_session'
custom_bot_account_session_folder = 'sessions/custom_bot_phone_session'
custom_admin_account_session_folder = 'sessions/custom_admin_phone_session'
scraper_account_session_folder = 'saved_settings/chat_scraper_settings/scraper_phone_session'


listener_account_phone_txt = 'saved_settings/live_cloner_settings/livecloner_listener_phone.txt'
scraper_account_phone_txt = 'saved_settings/custom_cloner_settings/chatscraper_phone.txt'



livecloner_temp_media_folder= 'app_data/livecloner_temp_files'
livecloner_temp_profile_folder="app_data/livecloner_temp_profiles"


livesettings_file_path='saved_settings/live_cloner_settings/settings_livecloner.json'
scraper_settings_file_path='saved_settings/chat_scraper_settings/settings_chatscraper.json'
custom_settings_file_path='saved_settings/custom_cloner_settings/settings_customchats.json'



livesettings_source_group_file_path='saved_settings/live_cloner_settings/livecloner_source_group.txt'
livesettings_destination_group_file_path='saved_settings/live_cloner_settings/livecloner_destination_group.txt'
scraper_settings_source_group_file_path='saved_settings/chat_scraper_settings/chat_scraper_source_group.txt'
custom_settings_destination_group_filepath='saved_settings/custom_cloner_settings/custom_cloner_destination_group.txt'

custom_messages_txt_file='messages.txt'
custom_media_folder='photos_and_videos'

chat_scraper_scraped_names_csv_file='profiles/names_list.csv'
chat_scraper_scraped_bio_csv_file='profiles/bios_list.csv'
chat_scraper_scraped_profile_photos_folder='profiles/profile_pictures'

if not os.path.exists(sessions_folder):
    os.mkdir(sessions_folder)

if not os.path.exists(custom_media_folder):
    os.mkdir(custom_media_folder)
if not os.path.exists(chat_scraper_scraped_profile_photos_folder):
    os.mkdir(chat_scraper_scraped_profile_photos_folder)

if not os.path.exists(scraper_account_session_folder):
    os.mkdir(scraper_account_session_folder)


if not os.path.exists(listener_account_session_folder):
    os.mkdir(listener_account_session_folder)

if not os.path.exists(custom_bot_account_session_folder):
    os.mkdir(custom_bot_account_session_folder)
if not os.path.exists(custom_admin_account_session_folder):
    os.mkdir(custom_admin_account_session_folder)

if not os.path.exists(livecloner_temp_media_folder):
    os.mkdir(livecloner_temp_media_folder)


if not os.path.exists(chat_scraper_scraped_names_csv_file):
    open(chat_scraper_scraped_names_csv_file,"w")
if not os.path.exists(chat_scraper_scraped_bio_csv_file):
    open(chat_scraper_scraped_bio_csv_file,"w")

if not os.path.exists(livesettings_source_group_file_path):
    open(livesettings_source_group_file_path,"w")

if not os.path.exists(livesettings_destination_group_file_path):
    open(livesettings_destination_group_file_path,"w")
if not os.path.exists(scraper_settings_source_group_file_path):
    open(scraper_settings_source_group_file_path,"w")

if not os.path.exists(custom_settings_destination_group_filepath):
    open(custom_settings_destination_group_filepath,"w")


if not os.path.exists(sessions_phone_file):
    open(sessions_phone_file,"w")

if not os.path.exists(custom_messages_txt_file):
    open(custom_messages_txt_file,"w")

if not os.path.exists(scraper_account_phone_txt):
    open(scraper_account_phone_txt,"w")

if not os.path.exists(listener_account_phone_txt):
    open(listener_account_phone_txt,"w")




if not os.path.exists(profile_pictures_path):
    os.mkdir(profile_pictures_path)


if not os.path.exists(bios_list_path):
    open(bios_list_path,"w")

if not os.path.exists(names_list_path):
    open(names_list_path,"w")


if not os.path.exists(usernames_list_path):
    open(usernames_list_path,"w")
if not os.path.exists(saved_password_path):
    open(saved_password_path,"w")







if not os.path.exists(livesettings_file_path):
    open(livesettings_file_path,"w")

if not os.path.exists(scraper_settings_file_path):
    open(scraper_settings_file_path,"w")

if not os.path.exists(custom_settings_file_path):
    open(custom_settings_file_path,"w")    


Telegram_API=API_FILE
APIsss = open(Telegram_API)
content = APIsss.read()  # raw text from url
apis = content.splitlines()
number_of_api=len(apis)

TeleChoice=None






async def Get_Group_Entity(client,phone,stored_entities,targetgroupLink):
    def channel_data_to_telethon_entity(channel_data):
        if 'id' in channel_data and 'username' in channel_data:
            return InputPeerChannel(channel_id=channel_data['id'], access_hash=channel_data.get('access_hash', 0))
        else:
            raise ValueError("Invalid channel dictionary")  
    if phone in stored_entities:
        entity_data=stored_entities[phone]

        #input_peer_channel=channel_data_to_telethon_entity(entity_data)
        #entity = await client.get_entity(input_peer_channel)
        return entity_data                                         
    else:
        entity = await client.get_entity(targetgroupLink)
        #phone_entity = entity
        stored_entities[phone] = entity
        return entity 


async def Send_Typing_Status_While_Sending_Message_To_Group(client,entity,min_delay,max_delay):
    print(Style.BRIGHT + Fore.MAGENTA+"Sending Typing Status...")
    await client(functions.messages.SetTypingRequest(peer=entity, action=types.SendMessageTypingAction()))
    typing_delay_time=random.randint(min_delay, max_delay)
    time.sleep(typing_delay_time)
    await client(functions.messages.SetTypingRequest(peer=entity, action=types.SendMessageTypingAction()))
    typing_delay_time=random.randint(min_delay, max_delay)
    time.sleep(typing_delay_time)
    await client(functions.messages.SetTypingRequest(peer=entity, action=types.SendMessageTypingAction()))



def clear_folder(folder_path):
    folder_contents = os.listdir(folder_path)
    for item in folder_contents:
        item_path = os.path.join(folder_path, item)
        if os.path.isfile(item_path):
            os.remove(item_path)
        elif os.path.isdir(item_path):
            clear_folder(item_path)



async def join_chat_private(client, targetgroupHash,ee):
    targetgroupHash = targetgroupHash.replace("https://t.me/", "")
    targetgroupHash = targetgroupHash.replace("+", "")
    try:
        result = await client(functions.messages.ImportChatInviteRequest(hash=targetgroupHash))
        print(Style.BRIGHT + Fore.GREEN + "Successfully joined the chat: " + str(targetgroupHash))
        random_time = random.randint(1, 3)
        print(Fore.GREEN + "\nWaiting mini break between groups:  " + str(random_time) + " Seconds...")
        await asyncio.sleep(random_time)
        return True
    except Exception as e:
        if 'already a participant of the chat' in str(e):
            print(Fore.GREEN+f"Already member private group: {targetgroupHash}: ")
            return True
        else:
            print(Style.BRIGHT + Fore.RED+f"Failed to join chat: {targetgroupHash}",e)
            print(Style.BRIGHT + Fore.RED+f"Failed to join chat: {targetgroupHash}",ee)
            return None


async def group_and_channel_joiner(destination_group_txt_to_load, return_to):

    print_section_title("Alex Joiner")

    destination_group_links_retrieved = None
    try:
        with open(destination_group_txt_to_load, 'r') as file:
            destination_group_links_retrieved = file.read()
    except:
        destination_group_links_retrieved = None
    print(Style.BRIGHT + Fore.GREEN + '                 [1] ' + Style.BRIGHT + Fore.GREEN + 'Join Already set Destination Groups(' + Style.BRIGHT + Fore.YELLOW + str(destination_group_links_retrieved) + Style.BRIGHT + Fore.GREEN + ")")
    print(Style.BRIGHT + Fore.GREEN + '                 [2] ' + Style.BRIGHT + Fore.CYAN + 'Enter new Group Link to join (' + Style.BRIGHT + Fore.BLUE + " Example: t.me/mygroup or t.me/+tmhhg7khkxs" + Style.BRIGHT + Fore.CYAN + "):")
    print(Style.BRIGHT + Fore.RED + '                 [0] ' + Style.BRIGHT + Fore.RED + 'Back')

    This_is_normal_Apexchat = input('\nEnter your choice: ')

    try:
        This_is_normal_Apexchat = int(This_is_normal_Apexchat)
    except Exception as e:
        print("Error Occurred!\n", e)
        await return_to

    if This_is_normal_Apexchat == 1:
        # Join groups from the file
        with open(destination_group_txt_to_load, 'r') as file:
            group_links = file.read().split(',')
        group_links = [link.strip() for link in group_links if link.strip()]
        if len(group_links) > 5:
            print(Style.BRIGHT + Fore.RED + "You can only enter up to 5 links. Please try again.")
            return

        colorama.init(autoreset=True)
        print(Style.BRIGHT + Fore.GREEN+ 'Starting...\n')

        print("Your Destination Groups/Channels:\n"+str(destination_group_links_retrieved))

        try:
            with open(sessions_phone_file, 'r') as f:
                str_list = [row[0] for row in csv.reader(f)]
                po = 1
                for pphone in str_list:
                    useapi = apis[po % number_of_api]
                    apidata = useapi.split()
                    IdToUse = apidata[0]
                    ApiToUse = apidata[1]

                    phone = utils.parse_phone(pphone)
                    print(Style.BRIGHT + Fore.RED + "-" + str(po) + Fore.CYAN + "-Account: " + Fore.GREEN + str(phone))
                    po += 1

                    try:
                        client = TelegramClient(f"{sessions_folder}/{phone}", IdToUse, ApiToUse)

                        try:
                            # Start the client; skip if not authorized
                            await client.connect()
                        except AuthKeyUnregisteredError:
                            print(Style.BRIGHT + Fore.RED + f"Phone {phone} is not authorized. Skipping this account.")
                            continue  # Skip to the next phone number

                        await asyncio.sleep(random.randint(1, 4))

                        xcountt = 0

                        for link in group_links:
                            xcountt += 1
                            
                            print(Style.BRIGHT + Fore.GREEN + "-" + str(xcountt) + Fore.YELLOW + "- Group/Channel: " + Fore.CYAN + str(link))
                            targetgroupHash=link
                            try:
                                result = await client(JoinChannelRequest(targetgroupHash))
                                print(Style.BRIGHT + Fore.GREEN + "Successfully joined the chat: " + str(targetgroupHash))
                                random_time = random.randint(2, 6)
                                print(Fore.GREEN + "\nWaiting " + str(random_time) + " Seconds...")
                                await asyncio.sleep(random_time)
                            except Exception as e:
                                e=str(e) +" - "+str(targetgroupHash)
                                targetgroupHash = link.split('/')[-1]
                                if 'already a participant of the chat' in str(e):
                                    print(Fore.GREEN+f"Already member public group: {targetgroupHash}: ")
                                    await client.disconnect()
                                    continue
                                
                                random_time=random.randint(2, 6)
                                result = await join_chat_private(client, targetgroupHash,e)
                                print(Fore.GREEN + "\nWaiting " + str(random_time) + " Seconds...")
                                await asyncio.sleep(random_time)
                            await asyncio.sleep(random_time)  # Wait between joining different groups

                        await client.disconnect()
                    except PhoneNumberBannedError:
                        print(Style.BRIGHT + Fore.RED + str(phone) + " has been banned")
                    except SessionPasswordNeededError:
                        print(Style.BRIGHT + Fore.RED + "Two-step verification is enabled")
                    except Exception as e:
                        print(Fore.RED + f"An error occurred while logging in: {e}")

                    


                print('Done')
        except Exception as e:
            print(f"An unexpected error occurred: {e}")
        print(Fore.GREEN + 'All Groups Joined Succeesfully!')
        await return_to
    elif This_is_normal_Apexchat == 2:
        print(Style.BRIGHT + Fore.MAGENTA + "\nJoin Destination Group/Channel")


        print(Style.BRIGHT + Fore.BLUE + "Enter up to " + str(maximum_group_links) + " group links separated by commas." +
              Style.BRIGHT + Fore.RED + "\nExample: \n" +
              Style.BRIGHT + Fore.YELLOW + "t.me/group1, t.me/+privategroup, t.me/group3")

        while True:
            join_link_source = input(Style.BRIGHT + Fore.GREEN + '\nEnter Group/Channel Link(s) separated by commas: ')
            group_links = [link.strip() for link in join_link_source.split(',') if link.strip()]

            # Remove duplicates
            group_links = list(set(group_links))

            # Validate each link
            valid_links = []
            for link in group_links:
                if "t.me/" in link and len(link) <= 50 and ' ' not in link:
                    valid_links.append(link)

            # Validate input
            if len(group_links) == 0:
                print(Style.BRIGHT + Fore.RED + "No links provided. Please try again.")
                continue
            if len(valid_links) == 0:
                print(Style.BRIGHT + Fore.RED + "No valid links provided. Each link must contain 't.me/', be less than or equal to 50 characters long, and not contain spaces. Please try again.")
                continue
            if len(valid_links) > maximum_group_links:
                print(Style.BRIGHT + Fore.RED + "You can only enter up to " + str(maximum_group_links) + " links. Please try again.")
                continue

            # Proceed with valid links


            print("Your Groups/Channels:\n"+str(valid_links))

            colorama.init(autoreset=True)
            print(Style.BRIGHT + Fore.RESET + 'Starting...\n')

            try:
                with open(sessions_phone_file, 'r') as f:
                    str_list = [row[0] for row in csv.reader(f)]
                    po = 1
                    for pphone in str_list:
                        useapi = apis[po % number_of_api]
                        apidata = useapi.split()
                        IdToUse = apidata[0]
                        ApiToUse = apidata[1]

                        phone = utils.parse_phone(pphone)
                        print(Style.BRIGHT + Fore.RED + "-" + str(po) + Fore.CYAN + "-Account: " + Fore.GREEN + str(phone))
                        po += 1

                        try:
                            client = TelegramClient(f"{sessions_folder}/{phone}", IdToUse, ApiToUse)
                            try:
                                # Start the client; skip if not authorized
                                await client.connect()
                            except AuthKeyUnregisteredError:
                                print(Style.BRIGHT + Fore.RED + f"Phone {phone} is not authorized. Skipping this account.")
                                continue  # Skip to the next phone number
                            await asyncio.sleep(random.randint(1, 4))

                            xcountt = 0
                            for link in valid_links:
                                xcountt += 1
                                targetgroupHash = link.split('/')[-1]
                                print(Style.BRIGHT + Fore.GREEN + "-" + str(xcountt) + Fore.YELLOW + "- Group/Channel: " + Fore.CYAN + str(link))
                                try:
                                    result = await client(JoinChannelRequest(targetgroupHash))
                                    print(Style.BRIGHT + Fore.GREEN + "Successfully joined the chat: " + str(targetgroupHash))
                                    random_time = random.randint(2, 6)
                                    print(Fore.GREEN + "\nWaiting " + str(random_time) + " Seconds...")
                                    await asyncio.sleep(random_time)
                                except Exception as e:
                                    if 'already a participant of the chat' in str(e):
                                        print(Fore.GREEN+f"Already member: {targetgroupHash}: ")
                                        await client.disconnect()
                                        continue
                                    result = await join_chat_private(client, targetgroupHash,e)
                                await asyncio.sleep(random.randint(2, 6))  # Wait between joining different groups

                            await client.disconnect()
                        except PhoneNumberBannedError:
                            print(Style.BRIGHT + Fore.RED + str(phone) + " has been banned")
                        except SessionPasswordNeededError:
                            print(Style.BRIGHT + Fore.RED + "Two-step verification is enabled")
                        except Exception as e:
                            print(f"An unexpected error occurred while logging in: {e}")

                        random_time = random.randint(2, 6)
                        print(Fore.GREEN + "\nWaiting " + str(random_time) + " Seconds...")
                        await asyncio.sleep(random_time)


                    print('Done')
            except Exception as e:
                print(f"An unexpected error occurred: {e}")

            break  # Exit loop once valid input is processed

        print(Fore.GREEN + 'All Groups Joined Succeesfully!')
        await return_to

    elif This_is_normal_Apexchat == 0:
        await return_to



async def set_destination_group(file_path_to_get_number, return_to):

    print_section_title("Destination Groups")

    # Function to validate the group links
    def is_valid_link(link):
        # Regex pattern to check if 't.me/' exists anywhere in the string
        pattern = r'(t\.me/[\w\+]{3,})'
        return bool(re.search(pattern, link.strip()))

    while True:
        # Prompt user to enter multiple group links separated by commas
        print(Style.BRIGHT + Fore.MAGENTA + "\n\nEnter up to "+str(maximum_group_links)+" group links separated by commas." +
              Style.BRIGHT + Fore.RED + " Example: \n" +
              Style.BRIGHT + Fore.YELLOW + "t.me/group1, t.me/+privategroup,t.me/group3")
        group_links = input(Style.BRIGHT + Fore.GREEN + "Example of group link: t.me/yourgroupname or t.me/+x283jsdy82):\n\n" +
                            Style.BRIGHT + Fore.BLUE + "Enter your Links here: ")

        # Split input by commas and strip whitespace from each link
        group_links_list = [link.strip() for link in group_links.split(",")]

        # Remove duplicates while preserving order
        seen_links = set()
        unique_group_links_list = []
        for link in group_links_list:
            if link not in seen_links:
                unique_group_links_list.append(link)
                seen_links.add(link)

        # Check if the user has entered more than 5 links
        if len(unique_group_links_list) > maximum_group_links:
            print(Style.BRIGHT + Fore.RED + "You can only enter up to 5 links. Please try again.")
            continue

        # Validate each link
        invalid_links = [link for link in unique_group_links_list if not is_valid_link(link)]

        if invalid_links:
            # If there are any invalid links, notify the user and ask for reentry
            print(Style.BRIGHT + Fore.RED + "\nOOPS! The following links are Invalid: ", ", ".join(invalid_links))
            print(Style.BRIGHT + Fore.RED + "Please ensure each link is valid, has no spaces, and is at least 3 characters long.")
        else:
            try:
                # Save the valid, unique links to the file
                with open(file_path_to_get_number, 'w') as file:
                    file.write(", ".join(unique_group_links_list))
                    print(Style.BRIGHT + Fore.GREEN + "Links saved successfully")
                await return_to
                break
            except Exception as e:
                print(Style.BRIGHT + Fore.RED + "Error: ", e)
                pass
                break
    await return_to









async def set_destination_group(file_path_to_get_number, return_to):
    # Function to validate the group links
    def is_valid_link(link):
        # Regex pattern to check if 't.me/' exists anywhere in the string
        pattern = r'(t\.me/[\w\+]{3,})'
        return bool(re.search(pattern, link.strip()))

    while True:
        # Prompt user to enter multiple group links separated by commas
        print(Style.BRIGHT + Fore.MAGENTA + "\n\nEnter up to 5 group links separated by commas." +
              Style.BRIGHT + Fore.RED + " Example: \n" + 
              Style.BRIGHT + Fore.YELLOW + "t.me/group1, t.me/+privategroup,t.me/group3")
        group_links = input(Style.BRIGHT + Fore.GREEN + "Example of group link: t.me/yourgroupname or t.me/+x283jsdy82):\n\n" + 
                            Style.BRIGHT + Fore.BLUE + "Enter your Links here: ")

        # Split input by commas and strip whitespace from each link
        group_links_list = [link.strip() for link in group_links.split(",")]

        # Remove duplicates while preserving order
        seen_links = set()
        unique_group_links_list = []
        for link in group_links_list:
            if link not in seen_links:
                unique_group_links_list.append(link)
                seen_links.add(link)

        # Check if the user has entered more than 5 links
        if len(unique_group_links_list) > 5:
            print(Style.BRIGHT + Fore.RED + "You can only enter up to 5 links. Please try again.")
            continue

        # Validate each link
        invalid_links = [link for link in unique_group_links_list if not is_valid_link(link)]

        if invalid_links:
            # If there are any invalid links, notify the user and ask for reentry
            print(Style.BRIGHT + Fore.RED + "\nOOPS! The following links are Invalid: ", ", ".join(invalid_links))
            print(Style.BRIGHT + Fore.RED + "Please ensure each link is valid, has no spaces, and is at least 3 characters long.")
        else:
            try:
                # Save the valid, unique links to the file
                with open(file_path_to_get_number, 'w') as file:
                    file.write(", ".join(unique_group_links_list))
                    print(Style.BRIGHT + Fore.GREEN + "Links saved successfully")
                await return_to
                break
            except Exception as e:
                print(Style.BRIGHT + Fore.RED + "Error: ", e)
                pass
                break



            
     


def count_lines_in_file(file_path):
    try:
        with open(file_path, 'r', encoding='UTF-8') as file:
            line_count = sum(1 for _ in file)
        return line_count
    except FileNotFoundError:
        print(f"File {file_path} not found.")
        return 0
    except Exception as e:
        print(f"An error occurred: {e}")
        return 0



async def check_if_listener_is_logged_in(fpath):
    try:
        with open(fpath, mode='r') as file:
            listener_acc_status = "Logged out"
            # Read the first line
            first_line = file.readline().strip()
            listener_phone_number = first_line

            if listener_phone_number is None or str(listener_phone_number) == "":
                listener_acc_status = Style.BRIGHT + Fore.RED+"No Phone"
                return listener_acc_status
            else:
                listener_phone = utils.parse_phone(listener_phone_number)

                '''if number_of_api <= 0:
                    listener_acc_status = Style.BRIGHT + Fore.YELLOW+"Invalid API"
                    return listener_acc_status


                useapi = apis[0]
                apidata = useapi.split()
                IdToUse = apidata[0]
                ApiToUse = apidata[1]
                asyncio.set_event_loop(asyncio.SelectorEventLoop())

                client = TelegramClient(f"{listener_account_session_folder}/{listener_phone}", IdToUse, ApiToUse)
                await client.connect()

                # Await the get_me() function to check login status
                me = await client.get_me()
                if not me:
                    listener_acc_status = Style.BRIGHT + Fore.RED+f"{listener_phone_number} - Logged out"
                else:
                    await client.disconnect()'''
                listener_acc_status = Style.BRIGHT + Fore.GREEN+f"{listener_phone_number}"
            return listener_acc_status

    except Exception as e:
        listener_acc_status = Style.BRIGHT + Fore.RED+f"Error: {str(e)}"
        return listener_acc_status

async def check_if_listener_is_logged_in_telethon(fpath):

    print_section_title("Login Checker")

    try:
        with open(fpath, mode='r') as file:
            listener_acc_status = "Logged out"
            # Read the first line
            first_line = file.readline().strip()
            listener_phone_number = first_line

            if listener_phone_number is None or str(listener_phone_number) == "":
                listener_acc_status = Style.BRIGHT + Fore.RED+"No Phone"
                return listener_acc_status
            else:
                listener_phone = utils.parse_phone(listener_phone_number)

                if number_of_api <= 0:
                    listener_acc_status = Style.BRIGHT + Fore.YELLOW+"Invalid API"
                    return listener_acc_status


                useapi = apis[0]
                apidata = useapi.split()
                IdToUse = apidata[0]
                ApiToUse = apidata[1]
                asyncio.set_event_loop(asyncio.SelectorEventLoop())

                client = TelegramClient(f"{listener_account_session_folder}/{listener_phone}", IdToUse, ApiToUse)
                await client.connect()

                # Await the get_me() function to check login status
                me = await client.get_me()
                if not me:
                    listener_acc_status = Style.BRIGHT + Fore.RED+f"{listener_phone_number} - Logged out"
                else:
                    await client.disconnect()
                    listener_acc_status = Style.BRIGHT + Fore.GREEN+f"{listener_phone_number} - Logged in"
            return listener_acc_status

    except Exception as e:
        listener_acc_status = Style.BRIGHT + Fore.RED+f"Error: {str(e)}"
        return listener_acc_status









async def set_source_group(xlistener_account_phone_txt,xlistener_account_session_folder,xlivesettings_source_group_file_path,return_to):

    print_section_title("Source Group")

    listener_phone_number = None  
    print(Style.BRIGHT + Fore.WHITE + f"\n" + Style.BRIGHT + Fore.WHITE + "Ensure to put your Listener Account in " + Style.BRIGHT + Fore.YELLOW + " :" + str(listener_account_phone_txt))
    #nonlocal listener_phone_number  # To modify the outer variable
    print("JOIN SOURCE GROUP WITH LISTENER ACCOUNT FIRST!")
    with open(xlistener_account_phone_txt, mode='r') as file:
        first_line = file.readline().strip()
        listener_phone_number = first_line

        if listener_phone_number is None or str(listener_phone_number) == "":
            print(Style.BRIGHT + Fore.RED + "The phone number in the first line is None\nPlease put Scraper Account in phone_scraper.csv before retrying" + Style.BRIGHT + Fore.YELLOW + " :" + str(listener_account_phone_txt))
            input("Press Enter")
            return

        else:
            print(Style.BRIGHT + Fore.GREEN + "The listener account number is:", listener_phone_number)

    listener_phone = utils.parse_phone(listener_phone_number)

    if number_of_api <= 0:
        print(Style.BRIGHT + Fore.RESET + 'Please input API in API.txt\n')
        input("Press Enter to Quit")
        quit()

    useapi = apis[0]
    apidata = useapi.split()
    IdToUse = apidata[0]
    ApiToUse = apidata[1]
    print(Style.BRIGHT + Fore.BLUE + f"\nListener Login " + Style.BRIGHT + Fore.RED + f"{listener_phone_number} -" + Style.BRIGHT + Fore.WHITE + f" please wait...")

    asyncio.set_event_loop(asyncio.SelectorEventLoop())

    client = TelegramClient(f"{xlistener_account_session_folder}/{listener_phone}", IdToUse, ApiToUse)
    await client.connect()
    me = await client.get_me()
    if not me:
        print(Style.BRIGHT + Fore.RED + f"Listener {listener_phone} Not logged in.\nPlease login first!\n")
        input('Press Enter to Quit!')
        return
    else:
        print(Style.BRIGHT + Fore.GREEN + "Please wait as we enlist all joined groups and channels - " + str(listener_phone))


        try:
            if await client.is_user_authorized():
                chats = []
                last_date = None
                chunk_size = 200
                groups_and_channels = []  # Combine groups and channels into one list
                
                # Fetch the dialogs (groups/channels)
                result = await client(GetDialogsRequest(
                    offset_date=last_date,
                    offset_id=0,
                    offset_peer=InputPeerEmpty(),
                    limit=chunk_size,
                    hash=0
                ))

                chats.extend(result.chats)

                # Filter for groups and channels
                for chat in chats:
                    try:
                        # Ensure chat has an 'entity' with a 'status' (checking if it's a valid group/channel)
                        if chat.megagroup or chat.broadcast:  # Check if it's a group (megagroup) or channel (broadcast)
                            groups_and_channels.append(chat)
                    except:
                        continue

                # Display available groups and channels to the user
                print(Style.BRIGHT + Fore.YELLOW + '\nChoose a group or channel to scrape members from >>')

                for i, g in enumerate(groups_and_channels):
                    print(Style.BRIGHT + Fore.RESET + f"{i} >> {g.title}")




                def sanitize_title(title):
                    # Remove emojis (using a regex that matches emoji patterns)
                    emoji_pattern = re.compile(
                        "["
                        "\U0001F600-\U0001F64F"  # emoticons
                        "\U0001F300-\U0001F5FF"  # symbols & pictographs
                        "\U0001F680-\U0001F6FF"  # transport & map symbols
                        "\U0001F1E0-\U0001F1FF"  # flags (iOS)
                        "\U00002702-\U000027B0"  # other symbols
                        "\U000024C2-\U0001F251"  # enclosed characters
                        "]+", flags=re.UNICODE)
                    
                    title_no_emoji = emoji_pattern.sub(r'', title)

                    # Remove any characters that are not alphanumeric, spaces, or hyphens
                    title_no_special_chars = re.sub(r'[^a-zA-Z0-9\s\-]', '', title_no_emoji)

                    # Replace multiple spaces with a single space
                    sanitized_title = re.sub(r'\s+', ' ', title_no_special_chars).strip()

                    return sanitized_title


                try:
                    # Prompt the user to select a group/channel by index
                    g_index = input(Style.BRIGHT + Fore.YELLOW + "\nEnter a Number >> ")
                    g_index = int(g_index)

                    # Ensure the list is not empty and the index is within the valid range
                    if len(groups_and_channels) == 0:
                        print(Fore.RED + "No groups or channels found.")
                        return
                    
                    if 0 <= g_index < len(groups_and_channels):
                        target_grp = groups_and_channels[g_index]

                        
                        # Ensure target_grp has the attributes we expect
                        if hasattr(target_grp, 'id') and hasattr(target_grp, 'title'):
                            channel_id = target_grp.id
                            channel_title = target_grp.title
                            channel_title=sanitize_title(channel_title)

  

                            # Prepare the channel data string with the sanitized title
                            channel_data = f"{channel_id}--{channel_title}"

                            print(f"Selected Group/Channel: {channel_data}")
                            print(Fore.GREEN + "Please wait...")

                            try:
                                # Write to file using 'utf-8' encoding to handle Unicode characters
                                with open(xlivesettings_source_group_file_path, 'w', encoding='utf-8') as file:
                                    file.write(f'{channel_data}')
                            except Exception as e:
                                print("Error writing to file: ", e)
                                pass
                            time.sleep(5)
                        else:
                            print(Fore.RED + "The selected group/channel does not have an 'id' or 'title'.")
                            time.sleep(5)
                    else:
                        print(Fore.RED + "Invalid index. Please enter a number within the valid range.")
                        return

                except ValueError:
                    print(Fore.RED + "Please enter a valid number.")
                    time.sleep(5)
                    return

                except Exception as e:
                    print(Fore.RED + "Error: ", e)
                    time.sleep(5)
                    return

  
                await client.disconnect()                    
                await return_to

            else:
                print(f"{listener_phone} - {xlistener_account_session_folder} is Not Logged in/connected")

        except Exception as e:
            print(e)
            print(Style.BRIGHT + Fore.RED + "The listener account isn't logged in yet.")















async def update_and_display_settings(file_path,return_to):

    print_section_title("Manage Settings")


    def save_settings(file_path, settings):
        with open(file_path, 'w') as file:
            json.dump(settings, file, indent=4)

    def display_settings(settings):
        print(Style.BRIGHT + Fore.GREEN+"\nChoose a number representing the setting you want to update:\n")
        idx = 1
        for key, value in settings.items():
            if key==live_replace_words:
                color = Fore.RED if str(value).lower() in ["none", "no"] else Fore.GREEN
                print(Style.BRIGHT + Fore.YELLOW + f"{idx} - " + Style.BRIGHT + Fore.WHITE + f"{key}:")
                idx += 1
                
                # Assuming `value` is a dictionary
                if isinstance(value, dict):
                    for group, replacements in value.items():
                        print(f"  {Style.BRIGHT + Fore.WHITE}Group: {Style.BRIGHT + Fore.CYAN + group}")
                        print(f"  {Style.BRIGHT + Fore.WHITE}Replacements: {Style.BRIGHT + color + replacements}")
                        idx += 1
                else:
                    # Handle case where `value` is not a dictionary if needed
                    print(f"  {Style.BRIGHT + Fore.WHITE}Value: {Style.BRIGHT + color + str(value)}")
            else:

                if value==None:
                    value="no"
                color = Fore.RED if str(value).lower() in ["none", "no"] else Fore.GREEN
                print(Style.BRIGHT + Fore.YELLOW + f"  {idx} -  " + Style.BRIGHT + Fore.WHITE + f"{key}: " + Style.BRIGHT + color + f"{value}")
                idx += 1
        print(Style.BRIGHT + Fore.RED +"  0 - Back to Main Menu\n")

    def is_yes_no(value):
        return value.upper() in ["YES", "NO"]

     

    def is_valid_replacement_text(value):
        # Define a regular expression pattern to match the format word==replacement_word
        pattern = r'^([a-zA-Z0-9_@]+==[a-zA-Z0-9_@]+)(,[a-zA-Z0-9_@]+==[a-zA-Z0-9_@]+)*$'
        
        # Check if the value matches the pattern
        return bool(re.match(pattern, value))



    def has_enough_numeric_characters(value):
        return sum(c.isdigit() for c in value) >= 10

    # Map settings keys to their corresponding input prompts



    prompts = {
    live_show_typing: "Should typing status be shown? NOTE: THIS WILL CAUSE DELAY IN MESSAGES (YES/NO): ",
    live_skip_msg_with_links: "Should all messages with links be skipped? (YES/NO): ",
    live_max_message_length: "Enter the maximum number of characters allowed in a message eg 300: ",
    live_clone_bot_messages: "Should messages from bots be cloned? (YES/NO): ",
    live_clone_admin_messages: "Should messages from admins be cloned? (YES/NO): ",
    live_custom_bot_acc: "Enter the custom bot account (or 'None' to use Default Account 1): ",
    live_custom_admin_acc: "Enter the custom admin account (or 'None' to use Default Account 1): ",
    live_change_names: "Should account profiles be matched? (YES/NO): ",
    live_replace_links_boolean: "Should all links be replaced with custom text? (YES/NO): ",
    livecloner_new_replacement_link: "Enter the link or text to replace all links with eg t.me/web_stop:  ",
    live_replace_words: "Enter the words replacement list. Use small caps(e.g., word1==replacement1, word2==replacement2): \n\nEnter new list: ",
    chat_scraper_number_of_messages: "Enter Number of Messages to Scrap: ",
    chat_scraper_min_delay: "Enter Min Delay Time in (s) eg 20 : ",
    chat_scraper_max_delay: "Enter Max Delay Time in (s) eg 40: ",
    chat_scraper_max_media_size: "Enter max media size for files and media (MB) eg 5: ",
    chat_scraper_scrap_sender_names: "Scrap Sender Names and Photos (YES/NO): ",
    fakechat_universal_delay: "Add + or - universal delay time (s) eg 5:"

}




    settings = load_settings(file_path)

    while True:
        display_settings(settings)
        choice = input("Choose a setting number: ").lower()
        if choice == 'done':

            await Manage_Live_Cloner_Function()
            break
        
        try:
            choice_num = int(choice)
            if 1 <= choice_num <= len(settings):
                idx = 1
                for key in settings:
                    if idx == choice_num:
                        while True:
                            if key!=live_replace_words:
                                prompt = prompts.get(key, f"Do you want to update {key}: ")
                                new_value = input(prompt).strip()
                                new_value = new_value.replace(" ", "")

                            def parse_boolean(value):
                                return value.strip().upper() == "YES"

                            boolean_keys = [
                                live_show_typing,
                                live_clone_bot_messages,
                                live_clone_admin_messages,
                                live_change_names,
                                live_skip_msg_with_links,
                                live_replace_links_boolean,
                                chat_scraper_scrap_sender_names
                            ]


                            if key == live_custom_bot_acc:
                                custom_bot_phone_number = None
                                # Validate the phone number
                                if str(new_value).lower()=="none":
                                    custom_bot_phone_number = None
                                    settings[key] = custom_bot_phone_number
                                    break
                                else:


                                    while not has_enough_numeric_characters(new_value):
                                        if str(new_value).lower()=="none":
                                            custom_bot_phone_number = None
                                            settings[key] = custom_bot_phone_number
                                            break
                                        print("The phone number is not valid. Please Try again")
                                        new_value = input(prompt).strip()
                                    custom_bot_phone_number = new_value
                                    if custom_bot_phone_number==None:
                                        break
                                    
                                
                                custom_bot_phone_number = utils.parse_phone(custom_bot_phone_number)
                                print(f"Currently using phone number: {custom_bot_phone_number}")  # Debug print
                                try:
                                    if number_of_api <= 0:
                                        print(Style.BRIGHT + Fore.RESET + 'Please input API in Telegram_API.txt\n')
                                        input("Press Enter to Quit")
                                        quit()
                                    api_select = random.randint(0, number_of_api - 1)
                                    useapi = apis[api_select]
                                    apidata = useapi.split()
                                    IdToUse = apidata[0]
                                    ApiToUse = apidata[1]
                                    print(Style.BRIGHT + Fore.BLUE + f"\nLogging into your Telegram account to send messages from bots: " + Style.BRIGHT + Fore.RED + f"{custom_bot_phone_number} -" + Style.BRIGHT + Fore.WHITE + f" please wait...")
                                    client = TelegramClient(f"{custom_bot_account_session_folder}/{custom_bot_phone_number}", IdToUse, ApiToUse)
                                    await client.connect()

                                    me = await client.get_me()
                                    if not me:
                                        try:
                                            result = await client.send_code_request(custom_bot_phone_number)
                                            phone_code_hash = result.phone_code_hash
                                            otp_code = input(f'{custom_bot_phone_number} - Please type in the confirmation code you received from Telegram to proceed: ').strip()
                                            await client.sign_in(custom_bot_phone_number, otp_code, phone_code_hash=phone_code_hash)
                                            print(Style.BRIGHT + Fore.GREEN + f"\n{custom_bot_phone_number} Logged in Successfully via OTP Code!")
                                            settings[key] = custom_bot_phone_number
                                        except SessionPasswordNeededError:
                                            account_password = input(Style.BRIGHT + Fore.RED + 'Password Required!\n' + Style.BRIGHT + Fore.BLUE + 'Enter the 2FA Password for: ').strip()
                                            await client.sign_in(custom_bot_phone_number, password=account_password, phone_code_hash=phone_code_hash)
                                            print(Style.BRIGHT + Fore.GREEN + f"\n{custom_bot_phone_number} Logged in Successfully via Password!")
                                            settings[key] = custom_bot_phone_number
                                        except Exception as e:
                                            print(Style.BRIGHT + Fore.RED + f"Error: {e}")
                                            continue
                                        finally:
                                            await client.disconnect()
                                    else:
                                        print(Style.BRIGHT + Fore.GREEN + f"The Custom Bot Account Account : {custom_bot_phone_number} is already signed in. \nNo Need to enter code again")
                                        settings[key] = custom_bot_phone_number
                                except Exception as e:
                                    print("Error: ", e)
                                
                                break







                            elif key == live_custom_admin_acc:
                                custom_admin_phone_number = None

                                

                                if str(new_value).lower() == "none":
                                    custom_admin_phone_number = None
                                    settings[key] = custom_admin_phone_number
                                    break
                                else:
                                    # Validate the phone number
                                    while not has_enough_numeric_characters(new_value):
                                        if str(new_value).lower() == "none":
                                            custom_admin_phone_number = None
                                            settings[key] = custom_admin_phone_number
                                            break
                                        print(Style.BRIGHT + Fore.RED + "The phone number is not valid. Please try again")
                                        new_value = input(prompt).strip()
                                    
                                    custom_admin_phone_number = new_value
                                    if custom_admin_phone_number==None:
                                        break


                                custom_admin_phone_number = utils.parse_phone(custom_admin_phone_number)
                                print(f"Currently using phone number: {custom_admin_phone_number}")  # Debug print
                                try:
                                    if number_of_api <= 0:
                                        print(Style.BRIGHT + Fore.RED + 'Please input API in Telegram_API.txt\n')
                                        input("Press Enter to Quit")
                                        quit()
                                    api_select = random.randint(0, number_of_api - 1)
                                    useapi = apis[api_select]
                                    apidata = useapi.split()
                                    IdToUse = apidata[0]
                                    ApiToUse = apidata[1]
                                    print(Style.BRIGHT + Fore.BLUE + f"\nLogging into your Telegram account to send messages from admins: " + Style.BRIGHT + Fore.RED + f"{custom_admin_phone_number} -" + Style.BRIGHT + Fore.WHITE + f" please wait...")
                                    client = TelegramClient(f"{custom_admin_account_session_folder}/{custom_admin_phone_number}", IdToUse, ApiToUse)
                                    await client.connect()

                                    me = await client.get_me()
                                    if not me:
                                        try:
                                            result = await client.send_code_request(custom_admin_phone_number)
                                            phone_code_hash = result.phone_code_hash
                                            otp_code = input(f'{custom_admin_phone_number} - Please type in the confirmation code you received from Telegram to proceed: ').strip()
                                            await client.sign_in(custom_admin_phone_number, otp_code, phone_code_hash=phone_code_hash)
                                            print(Style.BRIGHT + Fore.GREEN + f"\n{custom_admin_phone_number} Logged in Successfully via OTP Code!")
                                            settings[key] = custom_admin_phone_number
                                        except SessionPasswordNeededError:
                                            account_password = input(Style.BRIGHT + Fore.RED + 'Password Required!\n' + Style.BRIGHT + Fore.BLUE + 'Enter the 2FA Password for: ').strip()
                                            await client.sign_in(custom_admin_phone_number, password=account_password, phone_code_hash=phone_code_hash)
                                            print(Style.BRIGHT + Fore.GREEN + f"\n{custom_admin_phone_number} Logged in Successfully via Password!")
                                            settings[key] = custom_admin_phone_number
                                        except Exception as e:
                                            print(Style.BRIGHT + Fore.RED + f"Error: {e}")
                                            continue
                                        finally:
                                            await client.disconnect()
                                    else:
                                        print(Style.BRIGHT + Fore.GREEN + f"The Custom Admin Account Account : {custom_admin_phone_number} is already signed in. \nNo Need to enter code again")
                                        settings[key] = custom_admin_phone_number
                                except Exception as e:
                                    print("Error: ", e)
                                
                                settings[key] = new_value
                                break

                            

                            elif key==chat_scraper_number_of_messages:
                                while True:
                                    try:
                                        number_of_accounts = int(new_value)                                        
                                        if 0 < number_of_accounts < 10000:
                                            settings[key] = number_of_accounts
                                            break
                                        else:
                                            print(Style.BRIGHT + Fore.RED + "The number of accounts must be more than 0 and less than 10000.")
                                            new_value = input(prompt)
                                    except ValueError:
                                        print(Style.BRIGHT + Fore.RED + "Please enter a valid integer.")
                                        new_value = input(prompt)



                            


                            elif key==live_replace_words:

                                group=None

                                def update_replacements():
                                    """Update the replacement settings based on user input."""
                                    # Load the list of groups from the file
                                    with open(livesettings_destination_group_file_path, 'r') as file:
                                        groups_list = file.read().split(',')
                                    groups_list = [group.strip() for group in groups_list if group.strip()]

                                    if not groups_list:
                                        print(Style.BRIGHT + Fore.RED + "No Destination Group/Channel Detected in the file! Please set source group before proceeding!")
                                        return

                                    # Check if "Replace Specific Words" exists in settings, create if not
                                    if "Replace Specific Words" not in settings:
                                        settings["Replace Specific Words"] = {}

                                    # Print available groups
                                    print("Available Groups:")
                                    for idx, group in enumerate(groups_list, start=1):
                                        print(f"{idx}. {group}")

                                    try:
                                        # Ask user to select a group
                                        group_idx = int(input("Enter the number of the group to update: ").strip())
                                        if group_idx < 1 or group_idx > len(groups_list):
                                            raise ValueError("Group index out of range.")
                                        selected_group = groups_list[group_idx - 1]
                                    except (ValueError, IndexError):
                                        print(Style.BRIGHT + Fore.RED + "Invalid selection. Exiting...")
                                        return

                                    print(f"Selected Group: {selected_group}")

                                    # Ask the user for replacements
                                    new_value = input(f"Enter replacements for '{selected_group}' (format: word1==wordnew,word2==wordnew2): ").strip()

                                    # Validate the replacement text
                                    while not is_valid_replacement_text(new_value):
                                        print(Style.BRIGHT + Fore.RED + "Not a valid input. Use word1==wordnew,word2==wordnew2,word3==wordnew3")
                                        new_value = input(f"Enter replacements for '{selected_group}': ").strip()

                                    # Update the settings with the new replacements
                                    settings[str(live_replace_words)][selected_group] = new_value

                                    # Save the updated settings to the file
                                    with open(livesettings_file_path, 'w') as file:
                                        json.dump(settings, file, indent=4)

                                    print(Style.BRIGHT + Fore.GREEN + "Replacements updated successfully!")

                                update_replacements()






                                '''replacements=None
                                while not is_valid_replacement_text(new_value):
                                    print(Style.BRIGHT + Fore.RED +"Not a valid input. Use word1==wordnew,word2==wordnew2,word3==wordnew3")
                                    new_value = input(prompt)
                                    print(new_value)
                                settings[key] = new_value
                                break'''


                            elif key ==livecloner_new_replacement_link:
                                while not str(new_value)!="" and str(new_value).lower() != "none" and len(new_value)<=1:
                                    print(Style.BRIGHT + Fore.RED +"Not a valid input. Enter  Valid replacement link")
                                    new_value = input(prompt)
                                settings[key] = new_value
                                break







                            elif key in boolean_keys:
                                while not is_yes_no(new_value):
                                    print(Style.BRIGHT + Fore.RED + "Not a valid input. Use 'Y' or 'YES' to Enable or 'N' or 'NO' to Disable")
                                    new_value = input(f"Enter value for {key} (YES/NO): ").strip()

                                settings[key] = parse_boolean(new_value)


                            else:
                                settings[key] = new_value
                                break
                            break

                        save_settings(file_path, settings)
                        print(f"{key} has been successfully updated to {new_value}\n")
                        break
                        return return_to
                    idx += 1
            elif choice_num==0:
                await return_to
                break
            else:
                print("Invalid selection. Please try again.\n")
        except ValueError:
            print("Invalid input. Try selecting again.\n")



















async def accounts_manager(return_to):

    print_section_title("Accounts/Sessions")

    accounts_names_list_csv="./saved_settings/names_list.csv"
    accounts_bios_list_csv="./saved_settings/bios_list.csv"
    Phone_list_csv="./phone.csv"
    Phone_list_session_folder="./sessions"


    if not os.path.exists(Phone_list_session_folder):
        os.mkdir(Phone_list_session_folder)
    if not os.path.exists(Phone_list_csv):
        open(Phone_list_csv,"w")
    print_section_title("Accounts/Sessions")





    async def otp_login_sessions():
        use_device_info_full={}

        colorama.init(autoreset=True)
        print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')

        with open('phone.csv', 'r')as f:
            str_list = [row[0] for row in csv.reader(f)]
            po = 1
        #     result = set(str_list)
        # with open('phone.csv', 'w')as F:
        #     F.write('\n'.join(result))
            for pphone in str_list:

                


      

                if (po+1)<=number_of_api:
                        useapi =apis[po]
                else:
                    useapi =apis[po%number_of_api]
                
                apidata=useapi.split()
                IdToUse=apidata[0]
                ApiToUse=apidata[1]

    


    
                phone = utils.parse_phone(pphone)
                print(Style.BRIGHT + Fore.RED +" "+str(po)+Fore.CYAN+"-Login Account: "+ Fore.GREEN+str(phone))
                po=po+1


                client = TelegramClient(f"sessions/{phone}", IdToUse, ApiToUse)
                #await client.connect()

                
                await client.start(phone)
                if not await client.is_user_authorized():
                    try:    
                        # Check if the user is authorized
                        #me = await client.get_me()
                        #if not me:
                        await client.send_code_request(phone)
                        random_time=random.randint(1, 4)
                        print(Fore.GREEN +"\nWaiting "+str(random_time) +" Seconds...")
                        await asyncio.sleep(random_time)
                        await client.sign_in(phone, code)

                        # Check if the client requires a password
                        try:
                            await client.start(password=None)
                            print(Style.BRIGHT + Fore.GREEN+"Login successful via OTP\n")
                        except SessionPasswordNeededError:
                            password = input('Please enter your password: ')
                            await client.start(password=password)
                            print(Style.BRIGHT + Fore.GREEN+"Login successful via OTP & Password\n")

                        
                        

                    except PhoneNumberBannedError:
                        print(Style.BRIGHT + Fore.RED+str(phone)+" has been banned\n")
                    except errors.FloodWaitError as e: 
                        print('Flood Wait of ', e.seconds)

                    except Exception as e:
                        print(Style.BRIGHT + Fore.RED+f"Failed to login: {str(e)}\n")

                    finally:
                        await asyncio.sleep(random.randint(1, 4))
                        await client.disconnect()
                else:
                    print(Style.BRIGHT + Fore.GREEN+"Login successful via Session File\n")
                    random_time=random.randint(1, 4)
                    print(Fore.GREEN +"\nWaiting "+str(random_time) +" Seconds...")
                    await asyncio.sleep(random_time)
                    await client.disconnect()




            print(Style.BRIGHT + Fore.RESET + 'All Number Login Done !')
            print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to Exit')
            input()

       
    async def session_loader():
        global number_of_api

        print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')

        print(Style.BRIGHT + Fore.RED + "WARNING! This action will delete existing phone numbers from  'Phone.csv' ")

        print(Style.BRIGHT + Fore.CYAN + '[1] Quit')
        print(Style.BRIGHT + Fore.GREEN + '[2] Continue ')

        xhoice = int(input('Enter your choice: '))

        if xhoice == 1:
            quit()

        number_list = []
        extension = '*.session'
        session_files = glob.glob(os.path.join(sessions_folder, extension))

        po = 1
        for session_file in session_files:
            if (po + 1) <= number_of_api:
                useapi = apis[po]
            else:
                useapi = apis[po % number_of_api]

            apidata = useapi.split()
            IdToUse = apidata[0]
            ApiToUse = apidata[1]

            print(Style.BRIGHT + Fore.BLUE + "\nTrying to Load Session " + session_file)

            session_name = str(session_file)
            px = Path(session_file).stem
            target_phon_str = str(px)

            phone = utils.parse_phone(target_phon_str)
            print(Style.BRIGHT + Fore.RED + " " + str(po) + Fore.CYAN + "-Checking Account: " + Fore.GREEN + str(phone))
            po += 1

            try:
                client = TelegramClient(f"{sessions_folder}/{phone}", IdToUse, ApiToUse)
                await client.connect()

                if await client.is_user_authorized():
                    print(Style.BRIGHT + Fore.BLUE + "Loaded Phone: " + target_phon_str + " successfully")
                    print(Style.BRIGHT + Fore.GREEN + "Session detected and user is authorized\n")
                    po += 1

                    number_list.append(str(target_phon_str))

                    # Try to join the channel if needed
                    try:
                        await client(JoinChannelRequest(channelxd))
                    except:
                        print()

                    await asyncio.sleep(random.randint(2, 6))

                else:
                    print(Style.BRIGHT + Fore.RED + "Session not authorized. Skipping code sending.\n")

                    await asyncio.sleep(random.randint(2, 6))
                   
                await client.disconnect()

            except PhoneNumberBannedError:
                print(Style.BRIGHT + Fore.RED + str(phone) + " has been banned\n")
                os.remove(session_file)  # Deletes the unauthorized session file
                print("Session File Removed!")
            except SessionPasswordNeededError:
                print(Style.BRIGHT + Fore.RED + "Two-step verification is enabled\n")
            except Exception as e:
                print(f"An error occurred while logging in: {e}\n")

            finally:
                # Make sure the client is fully disconnected before attempting to delete the session file
                await client.disconnect()
                if not await client.is_user_authorized():
                    try:
                        os.remove(session_file)
                        print(Style.BRIGHT + Fore.RED + f"Deleted unauthorized session file: {session_file}")
                    except Exception as e:
                        print(f"Error deleting session file: {e}")

        # Save session numbers to CSV
        def save_list_as_csv(my_list, file_name):
            with open(file_name, 'w', newline='') as csv_file:
                writer = csv.writer(csv_file)
                for item in my_list:
                    writer.writerow([item])

        save_list_as_csv(number_list, sessions_phone_file)

        print(Style.BRIGHT + Fore.MAGENTA + "\nSuccessfully Saved SESSION NUMBERS in session_phones.csv")
        print(Style.BRIGHT + Fore.MAGENTA + "\nFound Telegram Accounts:")

        for number in number_list:
            print(Fore.GREEN + number)
        
        print(Style.BRIGHT + Fore.GREEN + "\nDone!!")
        print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to back')
        input()  





        
        







        
        
        










    

    async def ban_remover():
        MadeByRocky_200 = []
        init(autoreset=True)
        print(Style.BRIGHT + Fore.GREEN + 'Your License is Successfully Activated\n')

        banned_numbers = []

        with open(sessions_phone_file, 'r') as f:
            phone_numbers = [row[0] for row in csv.reader(f)]
        
        po = 1
        for phone in phone_numbers:
            # Rotate through available API keys
            if (po+1)<=number_of_api:
                    useapi =apis[po]
            else:
                useapi =apis[po%number_of_api]
            
            apidata=useapi.split()
            IdToUse=apidata[0]
            ApiToUse=apidata[1]

            # Parse and print phone info
            phone = utils.parse_phone(phone)
            print(Style.BRIGHT + Fore.RED + f"-{po}" + Fore.CYAN + f"- Checking Account: {Fore.GREEN}{phone}")
            po += 1

            
            client = TelegramClient(f"{sessions_folder}/{phone}", IdToUse, ApiToUse)
            try:
                # Start the client; skip if not authorized
                await client.connect()
            except AuthKeyUnregisteredError:
                print(Style.BRIGHT + Fore.RED + f"Phone {phone} is not authorized. Acc will be removed along with banned numbers.")
                banned_numbers.append(phone)
                continue  # Skip to the next phone number

            except PhoneNumberBannedError:
                print(Style.BRIGHT + Fore.RED + f"{phone} has been banned\n")
                banned_numbers.append(phone)
                await client.disconnect()
                continue

            
            except SessionPasswordNeededError:
                print(Style.BRIGHT + Fore.RED + "Two-step verification is enabled\n")
            
            except Exception as e:
                print(f"An error occurred while logging in: {e}\n")

            if await client.is_user_authorized():
                print(Style.BRIGHT + Fore.GREEN + f"Successfully Logged in: {phone}")
                await client.disconnect()
                continue
            else:
                print(Style.BRIGHT + Fore.RED + f"{phone} not\n")
                banned_numbers.append(phone)
                await client.disconnect()
                continue



            print()

        # Remove banned numbers from phone.csv
        if banned_numbers:
            print('List of Banned Numbers:')
            print(*banned_numbers, sep='\n')
            autoremove(banned_numbers)

        print(Style.BRIGHT + Fore.RESET + 'Done!')
        print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to exit')

    def autoremove(banned_numbers):
        # Remove banned numbers from 'phone.csv'
        with open(sessions_phone_file, "r") as infile:
            phone_list = [line.strip() for line in infile]

        remaining_numbers = [num for num in phone_list if num not in banned_numbers]

        with open(sessions_phone_file, "w", newline='') as outfile:
            writer = csv.writer(outfile)
            for number in remaining_numbers:
                writer.writerow([number])

        print("Done, all banned numbers have been removed.")


       


            


    async def spam_checker():
        bot = 'SpamBot'
        m = "Good news, no limits are currently applied to your account. You’re free as a bird!"
        rexhacks = "bird"
        r = 0
        MadeByRexhacks = []
        done = False
        

        colorama.init(autoreset=True)
        print(Style.BRIGHT + Fore.GREEN + 'Your License is Successfully Activated\n')
        done = False
        with open(sessions_phone_file, 'r')as f:
            str_list = [row[0] for row in csv.reader(f)]
            po = 1
        #     result = set(str_list)
        # with open('phone.csv', 'w')as F:
        #     F.write('\n'.join(result))
            for pphone in str_list:
                number_ban=True
  

  

            


      

                if (po+1)<=number_of_api:
                        useapi =apis[po]
                else:
                    useapi =apis[po%number_of_api]
                
                apidata=useapi.split()
                IdToUse=apidata[0]
                ApiToUse=apidata[1]

    

                
    
                phone = utils.parse_phone(pphone)
                print(Style.BRIGHT + Fore.RED +"-"+str(po)+Fore.CYAN+"-Account: +"+ Fore.GREEN+str(phone))
                po=po+1

                try:
                    client = TelegramClient(f"{sessions_folder}/{phone}", IdToUse, ApiToUse)
                    #await client.connect()
                    await client.start(phone)
                    time.sleep(random.randint(1, 4))
                    await client(functions.contacts.UnblockRequest(id='@SpamBot'))
                    time.sleep(random.randint(1, 2))
                    await client.send_message(bot, '/start')
                    time.sleep(random.randint(1, 4))
                    msg = str(await client.get_messages(bot))
                    if rexhacks in msg:
                        print(Style.BRIGHT + Fore.GREEN + m)
                        r += 1
                    else:
                        print(Style.BRIGHT + Fore.RED+ str(phone)+' is are limited')
                        Nero_op = str(pphone)
                        MadeByRexhacks.append(Nero_op)
                    
                    time.sleep(random.randint(2, 6))
                    print()
                    done = True
                    await client.disconnect()
                except PhoneNumberBannedError:
                    print(Style.BRIGHT + Fore.RED+str(phone)+" has been banned")
                except SessionPasswordNeededError:
                    print(Style.BRIGHT + Fore.RED+"Two-step verification is enabled")
                except Exception as e:
                    print(f"An error occurred while logging in: {e}")

                print()
                
            print('List Of limited Numbers')
        print(*MadeByRexhacks, sep='\n')
        print(f'{r} - Accounts Are Usable')   



    async def setprofilepic():
        print(Style.BRIGHT + Fore.RESET + 'Set/Delete Profile Picture')
        print('[1] Set Profile Picture \n[2] Delete Profile Picture \n[3] Set Different Pic per User ')
        epic = int(input('\nEnter your choice: '))

        print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        colorama.init(autoreset=True)
        print(Style.BRIGHT + Fore.RESET + 'Set Profile pictures (Put photos in pics folder)\n')

        # Load all images from the profile_pictures_path
        image_files = sorted([f for f in os.listdir(profile_pictures_path) if f.endswith(('.jpg', '.jpeg', '.png'))])

        if not image_files:
            print(Style.BRIGHT + Fore.RED + 'No images found in the pics folder!')
            return

        with open(sessions_phone_file, 'r') as f:
            str_list = [row[0] for row in csv.reader(f)]
            po = 1
            image_index = 0  # To track the current image

            for pphone in str_list:
                if image_index >= len(image_files):  # Stop if images are exhausted
                    print(Style.BRIGHT + Fore.YELLOW + 'No more images left to assign. Stopping.')
                    break

                imagepic = os.path.join(profile_pictures_path, image_files[image_index])

                # Switch API credentials based on phone number index
                if (po + 1) <= number_of_api:
                    useapi = apis[po]
                else:
                    useapi = apis[po % number_of_api]

                apidata = useapi.split()
                IdToUse = apidata[0]
                ApiToUse = apidata[1]

                phone = utils.parse_phone(pphone)
                print(Style.BRIGHT + Fore.RED + " " + str(po) + Fore.CYAN + " Changing Profile picture for: +" + Fore.GREEN + str(phone))
                po += 1

                client = TelegramClient(f"{sessions_folder}/{phone}", IdToUse, ApiToUse)
                await client.connect()

                if await client.is_user_authorized():
                    if epic == 1:
                        try:
                            result = await client(functions.photos.UploadProfilePhotoRequest(file=await client.upload_file('set.jpg')))
                            print(Style.BRIGHT + Fore.GREEN + 'done! profile pic has been changed')
                            await asyncio.sleep(random.randint(1, 5))
                        except Exception as e:
                            print(Style.BRIGHT + Fore.RED + f"Error: {e}")
                    elif epic == 2:
                        try:
                            await client(DeletePhotosRequest(await client.get_profile_photos('me')))
                            print(Style.BRIGHT + Fore.GREEN + 'Profile Pic Deleted')
                            await asyncio.sleep(random.randint(1, 5))
                        except Exception as e:
                            print(Style.BRIGHT + Fore.RED + f"Error: {e}")
                    elif epic == 3:
                        try:
                            result = await client(functions.photos.UploadProfilePhotoRequest(file=await client.upload_file(imagepic)))
                            image_index += 1  # Move to the next image
                            print(Style.BRIGHT + Fore.GREEN + f'done! profile pic {imagepic} has been changed')
                            await asyncio.sleep(random.randint(1, 5))
                        except Exception as e:
                            print(Style.BRIGHT + Fore.RED + f"Error: {e}")

                await asyncio.sleep(random.randint(1, 3))
                await client.disconnect()

        print(Style.BRIGHT + Fore.RESET + 'Done !')
        print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to back')
        quit()









                


    async def change_name_bio():
        names_list = []
        bios_list = []
        
        # Load names and bios from files
        with open(names_list_path, 'r', newline='', encoding='utf-8', errors='replace') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                names_list.append(row[0])

        with open(bios_list_path, 'r', newline='', encoding='utf-8', errors='replace') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                bios_list.append(row[0])

        print('[1] Change Name[All Accounts]\n[2] Change Name[Each Account]\n[3] Update Bio [All Accounts]\n')
        ename = int(input('\nEnter your choice: '))

        colorama.init(autoreset=True)
        print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')

        with open(sessions_phone_file, 'r') as f:
            str_list = [row[0] for row in csv.reader(f)]
            po = 1
            for pphone in str_list:                   
                if (po+1) <= number_of_api:
                    useapi = apis[po]
                else:
                    useapi = apis[po % number_of_api]
                
                apidata = useapi.split()
                IdToUse = apidata[0]
                ApiToUse = apidata[1]

                phone = utils.parse_phone(pphone)
                po += 1

                print(Style.BRIGHT + Fore.GREEN + f"Changing Name/Bio/Username/2fa for {phone}")
                
                client = TelegramClient(f"{sessions_folder}/{phone}", IdToUse, ApiToUse)
                await client.connect()

                if await client.is_user_authorized():
                    try:
                        if ename == 1:
                            name = input("Please enter a Name for all Accounts: ")
                            print(Style.BRIGHT + Fore.RED + f"Changing Name for: {phone}")
                            print("Name: " + name)
                            await client(UpdateProfileRequest(first_name=name, last_name=""))
                            print(Fore.GREEN + "Name Changed Successfully")

                        elif ename == 2:
                            if po-2 < len(names_list):
                                p_name = names_list[po-2]
                                print(Style.BRIGHT + Fore.RED + f"Changing Name for: {phone}")
                                print("Name: " + p_name)
                                await client(UpdateProfileRequest(first_name=p_name, last_name=""))
                                print(Fore.GREEN + f"Name Changed Successfully to: {p_name}")
                            else:
                                print(Fore.RED + "No more names available in the list.")
                                break

                        elif ename == 3:
                            if po-2 < len(bios_list):
                                bio = bios_list[po-2]
                                print(Style.BRIGHT + Fore.RED + f"Changing Bio for: {phone}")
                                print("Bio: " + bio)
                                await client(UpdateProfileRequest(about=bio))
                                print(Fore.GREEN + "Bio Changed Successfully")
                            else:
                                print(Fore.RED + "No more bios available in the list.")
                                break

                        else:
                            print("Invalid choice!")
                            break
                        
                        await asyncio.sleep(random.randint(1, 5))

                    except Exception as e:
                        print(Fore.RED + f"Error: {e}")
                        await asyncio.sleep(random.randint(1, 5))
                else:
                    print(Fore.RED + f"User is not authorized for {phone}")

                await client.disconnect()
                await asyncio.sleep(random.randint(1, 3))

        print(Style.BRIGHT + Fore.RESET + 'Done !')
        print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to back')
        input()








    





    async def set_usernames():
        NUMBER = ['1', '2', '0']
        LETTER = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n']
        print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
        print('update username')

        # Initialize usernames list
        usernames = []

        # Read phones
        if sessions_phone_file in os.listdir():
            with open(sessions_phone_file, 'r', encoding='UTF-8') as f:
                phones = f.read().strip().replace(' ', '').split()

        # Read usernames
        try:
            with open(usernames_list_path, 'r', encoding='UTF-8') as F:
                usernames = F.read().strip().split()
                if not usernames:
                    print(f'{Fore.RED}Error: Usernames list is empty!{Fore.RESET}')
                    return  # Exit if no usernames are found
        except Exception as e:
            print(f'{Fore.RED}Error: Usernames list file not found!{Fore.RESET}')
            print(e)
            return  # Exit if the file doesn't exist

        po = 1

        for phone in phones:
            if (po + 1) <= number_of_api:
                useapi = apis[po]
            else:
                useapi = apis[po % number_of_api]

            apidata = useapi.split()
            IdToUse = apidata[0]
            ApiToUse = apidata[1]
            po += 1

            # Check if we have enough usernames
            if po > len(usernames):
                print(f'{Fore.RED}Error: Not enough usernames for the number of phones!{Fore.RESET}')
                return

            # Assign username sequentially from the usernames list
            username = usernames[po - 1]

            try:
                print(f'Login to {Fore.GREEN}{phone}{Fore.RESET}')
                ph = utils.parse_phone(phone)
                client = TelegramClient(f"{sessions_folder}/{ph}", IdToUse, ApiToUse)
                await client.start(ph)

                # Try setting the username
                success = False
                attempt = 0

                while not success:
                    try:
                        modified_username = username if attempt == 0 else f'{username}_{"".join(random.choice(LETTER + NUMBER) for _ in range(3))}'
                        await client(UpdateUsernameRequest(modified_username))
                        print(f'{Fore.LIGHTYELLOW_EX}Username  successfully set for {Fore.GREEN}{phone}|{Fore.RED} Username : {modified_username}{Fore.RESET}\n')
                        success = True
                        await asyncio.sleep(random.randint(1, 2))
                    except errors.UsernameOccupiedError:
                        print(f'{Fore.RED}Username {modified_username} is taken, trying again...{Fore.RESET}')
                        attempt += 1
                        print("Retrying...please wait")
                        await asyncio.sleep(random.randint(1, 2))

                    except Exception as e:
                        print(f'{Fore.RED}Error occured',e)
                        attempt += 1
                        print("Retrying...please wait")
                        await asyncio.sleep(random.randint(1, 2))
                await client.disconnect()
            except errors.RPCError as E:
                print(E.__class__.__name__)





    
    async def Change_2fa():
        def save(phone, new_ps,hint ,old_ps=None):
            with open(saved_password_path, 'a', encoding='UTF-8') as f:
                f.write(f'|{phone}|old:{str(old_ps)}|new:{new_ps}|hint:{hint}\n')

        async def make_2step():
            print(Style.BRIGHT + Fore.RESET + 'Your License is Successfully Activated\n')
            print('Set 2step verify.')

            if sessions_phone_file in os.listdir():
                with open(sessions_phone_file, 'r', encoding='UTF-8') as f:
                    phones = f.read().strip().replace(' ', '').split()

            try:
                new_password = input("Please put your new password: ")
                hint = input("Please put your new password hint: ")
                po=0
                for phone in phones:
                    try:
                        if (po + 1) <= number_of_api:
                            useapi = apis[po]
                        else:
                            useapi = apis[po % number_of_api]

                        apidata = useapi.split()
                        IdToUse = apidata[0]
                        ApiToUse = apidata[1]
                        po += 1

                        print(f'login to {Fore.GREEN}{phone}{Fore.RESET}')
                        ph = utils.parse_phone(phone)
                        client = TelegramClient(f"{sessions_folder}/{ph}", IdToUse, ApiToUse)
                        await client.start(ph)
                        
                        # Check if the account already has 2FA enabled
                        a = await client(GetPasswordRequest())
                        if not a.has_password:
                            client.edit_2fa(new_password=new_password, hint=hint)
                            save(phone, hint,new_password)
                        else:
                            cur_pass = input("Enter current password: ")
                            client.edit_2fa(current_password=cur_pass, new_password=new_password, hint=hint)
                            save(phone, new_password, cur_pass)
                        
                        print(f'{Fore.CYAN}2FA set for {Fore.GREEN}{phone}{Fore.RESET}')
                        await client.disconnect()

                    except errors.RPCError as E:
                        print(E.__class__.__name__)

            except Exception as e:
                print(e)


        await make_2step()






    async def view_otp_code():
        chatop = 777000
        print(Style.BRIGHT + Fore.GREEN + 'OTP VIEWER. Press Enter to Move to NEXT Number ')
        with open(sessions_phone_file, 'r') as f:
            str_list = [row[0] for row in csv.reader(f)]

        print(Style.BRIGHT + Fore.YELLOW + "\nLogin Numbers")
        
        for index_acc, pphone in enumerate(str_list):
            # Determine API to use based on the index
            if (index_acc + 1) <= number_of_api:
                useapi = apis[index_acc]
            else:
                useapi = apis[index_acc % number_of_api]

            apidata = useapi.split()
            IdToUse = apidata[0]
            ApiToUse = apidata[1]

            phone = utils.parse_phone(pphone)
            print(Style.BRIGHT + Fore.RED + str(index_acc + 1) + Fore.CYAN + "- Using account: " + Fore.GREEN + str(phone))

            client = TelegramClient(f"sessions/{phone}", IdToUse, ApiToUse)

            await client.start(phone)

            if await client.is_user_authorized():
                try:
                    messages = await client.get_messages(chatop)
                    print(Style.BRIGHT + Fore.RESET + f"{messages[0].text}")
                    print(Style.BRIGHT + Fore.RED + 'Press Enter to go to Next Number')
                    k = input()
                except Exception as e:
                    print(f"Failed to Retrieve OTP: {e}")
                finally:
                    await asyncio.sleep(random.randint(1, 3))
                    await client.disconnect()
        
        print(Style.BRIGHT + Fore.RESET + 'All Number OTP View Done!')
        print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to back')
        input()


    async def log_out_other_sessions():
        print(Style.BRIGHT + Fore.RED + 'This action will delete all other logged-in session files! Be careful ')
        with open(sessions_phone_file, 'r') as f:
            str_list = [row[0] for row in csv.reader(f)]
        
        print(Style.BRIGHT + Fore.YELLOW + "\nLogin Numbers")
        
        for index_acc, pphone in enumerate(str_list):
            if (index_acc + 1) <= number_of_api:
                useapi = apis[index_acc]
            else:
                useapi = apis[index_acc % number_of_api]

            apidata = useapi.split()
            IdToUse = apidata[0]
            ApiToUse = apidata[1]

            phone = utils.parse_phone(pphone)
            print("\n")
            print(Style.BRIGHT + Fore.RED + str(index_acc + 1) + Fore.CYAN + "- Using account: " + Fore.GREEN + str(phone))

            client = TelegramClient(f"sessions/{phone}", IdToUse, ApiToUse)

            await client.start(phone)

            if await client.is_user_authorized():
                try:
                    # Fetch the current session's details
                    sessions = await client(functions.account.GetAuthorizationsRequest())
                    
                    # Print important attributes for each session
                    for i, session in enumerate(sessions.authorizations, start=1):
                        print(Fore.YELLOW +f"{pphone} Logged Session {i}")
                        print(f"Hash: {session.hash}")
                        print(f"Device Model: {session.device_model}")
                        print(f"System Version: {session.system_version}")
                        print(f"Date Created: {session.date_created}")
                        print(f"Date Active: {session.date_active}")
                        print(f"Country: {session.country}")

                        # Revoke the session if it's not the current session
                        if not session.current:
                            await client(functions.account.ResetAuthorizationRequest(
                                hash=session.hash
                            ))
                            print(Fore.GREEN +f"Revoked session with hash {session.hash}")
                            random_time = random.randint(2, 6)
                            print(Fore.GREEN + "\nWaiting " + str(random_time) + " Seconds...")
                            await asyncio.sleep(random_time)

                except Exception as e:
                    print(Fore.RED +f"Failed to Delete Sessions: {e}")
                finally:
                    await asyncio.sleep(random.randint(1, 3))
                    await client.disconnect()
        
        print(Style.BRIGHT + Fore.RESET + 'All Number Sessions Delete Done!')
        print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to go back')
        input()










    print_section_title("AlexChat - Manage Bulk Accounts")

    colorama.init(autoreset=True)
    print(Style.BRIGHT + Fore.BLUE + '                 [1] '+Style.BRIGHT + Fore.GREEN +'Login via OTP')
    print(Style.BRIGHT + Fore.BLUE + '                 [2] '+Style.BRIGHT + Fore.YELLOW +'Load Sessions from Files')
    print(Style.BRIGHT + Fore.BLUE + '                 [3] '+Style.BRIGHT + Fore.RED +'Delete Banned Numbers')
    print(Style.BRIGHT + Fore.BLUE + '                 [4] '+Style.BRIGHT + Fore.BLUE +'SpamBotChecker')
    print(Style.BRIGHT + Fore.BLUE + '                 [5] '+Style.BRIGHT + Fore.MAGENTA +'Bulk Update Profile Picture ')
    print(Style.BRIGHT + Fore.BLUE + '                 [6] '+Style.BRIGHT + Fore.CYAN +'Bulk Update Name/Bio')
    print(Style.BRIGHT + Fore.BLUE + '                 [7] '+Style.BRIGHT + Fore.GREEN +'Bulk Update Usernames')
    print(Style.BRIGHT + Fore.BLUE + '                 [8] '+Style.BRIGHT + Fore.YELLOW +'Modify Password/2FA')
    print(Style.BRIGHT + Fore.BLUE + '                 [9] '+Style.BRIGHT + Fore.BLUE+'View OTP Codes')
    print(Style.BRIGHT + Fore.BLUE + '                 [10] '+Style.BRIGHT + Fore.MAGENTA +'Log out all other active sessions')
    print(Style.BRIGHT + Fore.RED + '                 [0] Back')
    This_is_normal_Apexchat = int(input(Style.BRIGHT + Fore.BLUE +'\nEnter your choice: '))

    try:
        This_is_normal_Apexchat=int(This_is_normal_Apexchat)
    except Exception as e:
        print("Error Occurred!\n",e)
        await return_to

    if This_is_normal_Apexchat==1:
        await otp_login_sessions()
    elif This_is_normal_Apexchat==2:
        await session_loader()
    elif This_is_normal_Apexchat == 3:
        await ban_remover()
    elif This_is_normal_Apexchat == 4:
        await spam_checker()
    elif This_is_normal_Apexchat==5:
        await setprofilepic()
    elif This_is_normal_Apexchat==6:
        await change_name_bio()
    elif This_is_normal_Apexchat==7:
        await set_usernames()
    elif This_is_normal_Apexchat==8:
        await Change_2fa()
    elif This_is_normal_Apexchat==9:
        await view_otp_code()
    elif This_is_normal_Apexchat==10:
        await log_out_other_sessions()
    elif This_is_normal_Apexchat==0:
        await return_to
    else:
        print(Style.BRIGHT + Fore.RED +"Invalid Choice!")
        await accounts_manager(alex_main_menu())

































































async def chat_scraper_main_menu():
    print_section_title("Chat Scraper")

    async def login_scraper_acc():
        async def login_acc():
            scraper_phone_number = None  
            


            def is_valid_phone_number(phone_number):
                # Remove spaces from the input
                phone_number = re.sub(r"\s+", "", phone_number)
                
                # Regular expression to match a valid phone number
                pattern = r"^\+?[1-9]\d{9,14}$"
                
                return bool(re.fullmatch(pattern, phone_number))

            def get_valid_phone_number():
                    while True:
                        phone_number = input(Style.BRIGHT + Fore.RED+"Re-enter a valid phone number. No spaces allowed! "+Style.BRIGHT + Fore.BLUE+"\nEnter Phone Number: ")
                        
                        if is_valid_phone_number(phone_number):
                            return phone_number  # Return the valid phone number
                        else:
                            print(Style.BRIGHT + Fore.RED+"Invalid phone number. Please try again. No spaces allowed: "+Style.BRIGHT + Fore.BLUE+"\nEnter Phone Number: ")

            # Example usage
            valid_phone = get_valid_phone_number()
            scraper_phone_number=str(valid_phone)


            
            scraper_phone = utils.parse_phone(scraper_phone_number)

            if number_of_api<=0:
                print(Style.BRIGHT + Fore.RESET + 'Please input API in API.txt\n')
                input("Press Enter to Quit")
                quit()

            api_select = random.randint(0, number_of_api - 1)
            useapi = apis[api_select]
            apidata = useapi.split()
            IdToUse = apidata[0]
            ApiToUse = apidata[1]
            print(Style.BRIGHT + Fore.BLUE + f"\nScraper Login "+Style.BRIGHT + Fore.RED +f"{scraper_phone_number} -"+Style.BRIGHT + Fore.WHITE +f" please wait...")

            asyncio.set_event_loop(asyncio.SelectorEventLoop())

            client = TelegramClient(f"{scraper_account_session_folder}/{scraper_phone}", IdToUse, ApiToUse)
            await client.connect()
            me = await client.get_me()

            phone_code_hash=None
            account_password=None
            if not me:
                try:

                    result = await client.send_code_request(scraper_phone) 
                    phone_code_hash = result.phone_code_hash
                    await asyncio.sleep(1)
                    otp_code=input(f'{scraper_phone} - Enter Confirmation code: ')
                    await asyncio.sleep(2)
                    await client.sign_in(scraper_phone, otp_code, phone_code_hash=phone_code_hash)
                    print(Style.BRIGHT + Fore.GREEN + f"\n{scraper_phone} Logged in Successfully via OTP Code!")
                    save_phone_number_to_file(valid_phone,scraper_account_phone_txt)
                    client.disconnect()

                except SessionPasswordNeededError:
                    try:
                        account_password=input(Style.BRIGHT + Fore.RED +'Password Required!\n'+Style.BRIGHT + Fore.BLUE +'Enter the 2FA Password for: ')
                        await client.sign_in(scraper_phone, password=account_password, phone_code_hash=phone_code_hash)
                        client.disconnect()
                        print(Style.BRIGHT + Fore.GREEN + f"\n{scraper_phone_number} Logged in Successfully via Password!")
                        save_phone_number_to_file(valid_phone,scraper_account_phone_txt)
                    except PasswordHashInvalidError:
                        print(Style.BRIGHT + Fore.RED + f"Invalid Password for {scraper_phone}")
                        input('Press Enter to Quit!')
                        qui()
                    except Exception as e:
                        print(Style.BRIGHT + Fore.YELLOW + f"Error Signing {scraper_phone} with password due to :{account_password}\n"+Style.BRIGHT + Fore.RED+str(e))
                        input('Press Enter to Quit!')


                    await asyncio.sleep(2)
                except Exception as e:
                    print(Style.BRIGHT + Fore.YELLOW + f"Error Signing {scraper_phone} in due to:\n"+Style.BRIGHT + Fore.RED+str(e))
                    input('Press Enter to Quit!')
            else:
                print(Style.BRIGHT + Fore.GREEN +"Logged in Successfully - Saved Session File - "+str(scraper_phone))
                save_phone_number_to_file(valid_phone,scraper_account_phone_txt)
                client.disconnect()
            print(Style.BRIGHT + Fore.RESET + 'Done !')
            print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to back')




        async def load_acc():
            targetgroup=""
            global number_of_api
            if number_of_api<=0:
                print(Style.BRIGHT + Fore.RESET + 'Please input API in API.txt\n')
                input("Press Enter to Quit")
                quit()


            print(Style.BRIGHT + Fore.RED + f"WARNING! This action will replace contents of  {scraper_account_phone_txt}' ")

            print(Style.BRIGHT + Fore.GREEN + '[1] Continue')
            print(Style.BRIGHT + Fore.RED + '[2] Quit ')
            
            xhoice = int(input(Style.BRIGHT + Fore.BLUE+'Enter your choice: '))

            if xhoice!=1:
                quit()


            number_list = []
            extension = '*.session'
            session_files = glob.glob(os.path.join(scraper_account_session_folder, extension))
            po = 1



            for session_file in session_files:
                print(Style.BRIGHT + Fore.BLUE+"\nTrying to Load Session "+session_file)
                session_name = str(session_file)
                px = Path(session_file).stem
                #print(px)

                target_phon_str=str(px)


                if (po+1)<=number_of_api:
                        useapi =apis[po]
                else:
                    if number_of_api==0:
                        number_of_api=1
                    useapi =apis[po%number_of_api]
                
                apidata=useapi.split()
                IdToUse=apidata[0]
                ApiToUse=apidata[1]


                phone = utils.parse_phone(target_phon_str)
                if phone==None:
                    print(Style.BRIGHT + Fore.RED+"An error occurred while logging in: Session not valid. Make sure the session is named with its phone number!")
                print(Style.BRIGHT + Fore.RED +" "+str(po)+Fore.CYAN+"-Checking Account: "+ Fore.GREEN+str(phone))
                po=po+1

                try:
                    client = TelegramClient(f"{scraper_account_session_folder}/{phone}", IdToUse, ApiToUse)
                    #await client.connect()
                    await client.start(phone)
                    if await client.is_user_authorized():
                        print(Style.BRIGHT + Fore.BLUE + "Loaded Phone: " +target_phon_str+" successfully")
                        print(Style.BRIGHT + Fore.GREEN + "Session detected and user is authorized\n")

                        with open(scraper_account_phone_txt, 'w', encoding='UTF-8') as fn:
                            fn.write(f"{phone}\n")  # Write the phone number as a single line

                        print(Style.BRIGHT + Fore.GREEN + f"Successfully Saved ({phone}) Scraper SESSION NUMBER in {scraper_account_phone_txt}")
                        client.disconnect()
                        input("Press Enter to Exit")



                        
                    else:
                        print(Style.BRIGHT + Fore.RED + "Session not authorized\n")
                        time.sleep(random.randint(2, 6))
                    print()
                    done = True
                    await client.disconnect()
                except PhoneNumberBannedError:
                    print(Style.BRIGHT + Fore.RED+str(phone)+" has been banned\n")
                except SessionPasswordNeededError:
                    print(Style.BRIGHT + Fore.RED+"Two-step verification is enabled\n")
                except Exception as e:
                    print(f"An error occurred while logging in: {e}\n")


            print(Style.BRIGHT + Fore.GREEN + "\nDone!!")
            print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to back')
            input()



        print(Style.BRIGHT + Fore.RESET +"Checking current account...please wait")

        acc_status=await check_if_listener_is_logged_in_telethon(scraper_account_phone_txt)
        print(Style.BRIGHT + Fore.RED+f"Current Account Status: "+f"{acc_status}\n")
        print(Style.BRIGHT + Fore.BLUE + '                 [1] '+Style.BRIGHT + Fore.GREEN+'Login New Scraper (OTP)')
        print(Style.BRIGHT + Fore.BLUE + '                 [2] '+Style.BRIGHT + Fore.GREEN+'Load Scraper (SESSION)')
        print(Style.BRIGHT + Fore.BLUE + '                 [3]'+Style.BRIGHT + Fore.RED+' Back]')
        TeleChoice = (input('\nEnter your choice: '))

        try:
            TeleChoice=int(TeleChoice)
        except Exception as e:
            print("Error Occurred!\n",e)
            await login_scraper_acc()
        if TeleChoice==1:
            await login_acc() 
        elif TeleChoice==2:
            await load_acc()       
        elif TeleChoice==3:
            await chat_scraper_main_menu()
       
        else:
            print(Style.BRIGHT + Fore.RED +'\nInvalid Input!')
            await login_scraper_acc()



    async def dragonchatscraper():
        print(Style.BRIGHT + Fore.RED + "\nCUSTOM CHATS STARTING...!\n")

        Scraper_Cloner_Source_Group_ID = None
        Scraper_Cloner_Scraper_Account = None
        Scraper_Cloner_Bot_Message_Boolean = None
        Scraper_Cloner_Admin_Messages_Boolean = None
        Scraper_Cloner_Max_Message_Length = None
        Scraper_Cloner_Min_Delay=None
        Scraper_Cloner_Max_Delay=None
        Scraper_Cloner_Max_Media=None
        Scraper_Cloner_Number_Of_Messages=None
        Scraper_Skip_Messages_WIth_Links=None
        Scraper_Scrap_Sender_Names=None


        ph=""        
        accounts={}  
        phones={} 
        try:
            with open(sessions_phone_file, 'r', encoding='UTF-8')as f:
                phones = f.read()
                phones.strip()
                phones = phones.replace(' ' , '')
                phones = phones.split()
                f.close()
        except Exception as e:
            print(Style.BRIGHT + Fore.RED +"Minor Error Reading Phone.csv ",e)
            print(Style.BRIGHT + Fore.YELLOW+ "Proceeding...")
            pass
        countx=0 
        for phone in phones:
            ph = utils.parse_phone(phone) 
            countx=countx+1 
            accounts[countx]=ph 

        countx = countx if countx is not None else "Not Available"      
        

        messageselection=""
        messagetext=""
        replymessagetext=""
        imagepath=""
        senderaccount=""
        delayt=0
        targetgroup=""



        try:        
            

            source_group_retrieved_link=None
            try:
                with open(scraper_settings_source_group_file_path, 'r') as file:
                    source_group_retrieved_link = file.read()
            except:
                source_group_retrieved_link=None

            if source_group_retrieved_link==None:
                print("Could not find Destination Group")
                return None

            split_result = source_group_retrieved_link.split('--')
            first_element = split_result[0]
            Scraper_Source_Group_Name=split_result[1]
            if first_element.isnumeric():
                Scraper_Cloner_Source_Group_ID = int("-100" + first_element)
            else:
                print(Style.BRIGHT + Fore.RED +"Could not find Source Group ID from: ",Scraper_Source_Group_Name)
                return None



            with open(scraper_account_phone_txt, 'r') as file:
                Scraper_Cloner_Scraper_Account = file.read().split(',')
            if Scraper_Cloner_Scraper_Account==None or str(Scraper_Cloner_Scraper_Account)=="":
                print(Style.BRIGHT + Fore.RED +f"No Scraper Account in {scraper_account_phone_txt}! Please set Scraper Account before proceeding!")
                return None

                
                try:
                    print(f"Scraping Chats from Set Group: {Scraper_Source_Group_Name}")
                except ValueError:
                    print(Style.BRIGHT + Fore.RED+"Error! COuld not load Source Group.")
                    return None # Continue to the next iteration to re-prompt for the choice



            def get_value_by_key(settings, key):
                # Ensure this function returns a string or None
                return str(settings.get(key, "")).strip()  # Convert to string and strip any extra whitespace

            # Load settings from the file
            settings = load_settings(scraper_settings_file_path)

            # Process boolean settings
            Scraper_Cloner_Bot_Message_Boolean = get_value_by_key(settings, live_clone_bot_messages) 
            Scraper_Cloner_Admin_Messages_Boolean = get_value_by_key(settings, live_clone_admin_messages) 
            Scraper_Skip_Messages_With_Links = get_value_by_key(settings, live_skip_msg_with_links)

            # Process integer settings with default fallback values
            Scraper_Cloner_Number_Of_Messages = int(get_value_by_key(settings, chat_scraper_number_of_messages) or 0)
            Scraper_Cloner_Min_Delay = int(get_value_by_key(settings, chat_scraper_min_delay) or 0)
            Scraper_Cloner_Max_Delay = int(get_value_by_key(settings, chat_scraper_max_delay) or 0)
            Scraper_Cloner_Max_Message_Length = int(get_value_by_key(settings, live_max_message_length) or 0)
            Scraper_Cloner_Max_Media = float(get_value_by_key(settings, chat_scraper_max_media_size) or 0)

            # Process any non-boolean settings
            Scraper_Scrap_Sender_Names = get_value_by_key(settings, chat_scraper_scrap_sender_names)




            


           
            countx = countx if countx is not None else "Not Available"
            print(Style.BRIGHT + Fore.GREEN + "\nCHAT SCRAPER STARTING...")
            await asyncio.sleep(random.randint(1, 4))

            print(Style.BRIGHT + Fore.RED + "Your Current Scraper Cloner Settings!")

            print(Style.BRIGHT + Fore.RESET + "Source Group: " + Style.BRIGHT + Fore.GREEN + str(Scraper_Source_Group_Name))
            print(Style.BRIGHT + Fore.RESET + "Scraper Account " + Style.BRIGHT + Fore.GREEN + str(Scraper_Cloner_Scraper_Account[0]))
            print(Style.BRIGHT + Fore.RESET + "Number of Messages: " + Style.BRIGHT + Fore.GREEN + str(Scraper_Cloner_Number_Of_Messages))
            print(Style.BRIGHT + Fore.RESET + "Min Delay Time (s): " + Style.BRIGHT + Fore.GREEN + str(Scraper_Cloner_Min_Delay))
            print(Style.BRIGHT + Fore.RESET + "Max Delay Time (s): " + Style.BRIGHT + Fore.GREEN + str(Scraper_Cloner_Max_Delay))
            print(Style.BRIGHT + Fore.RESET + "Scrap Messages from Bots: " + Style.BRIGHT + Fore.GREEN + str(Scraper_Cloner_Bot_Message_Boolean))
            print(Style.BRIGHT + Fore.RESET + "Scrap Messages from Admins: " + Style.BRIGHT + Fore.GREEN + str(Scraper_Cloner_Admin_Messages_Boolean))
            print(Style.BRIGHT + Fore.RESET + "Max Message Length (characters): " + Style.BRIGHT + Fore.GREEN + str(Scraper_Cloner_Max_Message_Length))
            print(Style.BRIGHT + Fore.RESET + "Max Media Size (MB): " + Style.BRIGHT + Fore.GREEN + str(Scraper_Cloner_Max_Media))
            print(Style.BRIGHT + Fore.RESET + "Skip All Messages containing Links: " + Style.BRIGHT + Fore.GREEN + str(Scraper_Skip_Messages_WIth_Links))
            print(Style.BRIGHT + Fore.RESET + "Scrap Sender Names and Profile Pictures: " + Style.BRIGHT + Fore.GREEN + str(Scraper_Scrap_Sender_Names))
           


        except Exception as e:
            print("Error reading your Scraper Cloner Settings due to ",e)
            return None
        print("Pass")


        print(Style.BRIGHT + Fore.MAGENTA+'Scrap Chats from Target Group (With Autosave Media, emojis, replies...): ')   

        print(Style.BRIGHT + Fore.GREEN+"Chat Scrapping starting...\n")
        scraper_phone=utils.parse_phone(Scraper_Cloner_Scraper_Account[0])
        api_select = random.randint(0, number_of_api-1)

        useapi =apis[api_select]      
        
        apidata=useapi.split()
        IdToUse=apidata[0]
        ApiToUse=apidata[1]

        asyncio.set_event_loop(asyncio.SelectorEventLoop())

        client = TelegramClient(f"{scraper_account_session_folder}/{scraper_phone}", IdToUse,ApiToUse)
        await client.connect()
        me = await client.get_me()
        if not me:
            print(Style.BRIGHT + Fore.RED+f"Scraper Phoner Number({scraper_phone}) Disconnected!")
            input(Style.BRIGHT + Fore.RED+"Quitting...Press Enter")
            return None
        else:
            count = 0
            messagetype="n/a"
            sendersaxxountx={}
            printm=""
            accountlimit=10000
                  
            chats = []
            last_date = None
            chunk_size = 200
            groups=[]

            thislist = []
            senderacc=1
            sender_names=[]  
            sendingnow=1
            try:
                print(Style.BRIGHT + Fore.RED+f"Clearing Existing Message Contents...")
                with open(custom_messages_txt_file, 'w') as file:
                    file.write('')
                  
                with open(chat_scraper_scraped_names_csv_file, 'w') as file:
                    file.write('')
                   
                with open(chat_scraper_scraped_bio_csv_file, 'w') as file:
                    file.write('')
                    
                clear_folder(custom_media_folder)
                
                clear_folder(chat_scraper_scraped_profile_photos_folder)
              
            except Exception as e:
                print(Style.BRIGHT + Fore.RED+f"Error clearing contents of {custom_messages_txt_file}: {e}")

            justcaption=False
            admin_messages=[]

            from telethon.tl import types
            count=0
            try:
                admins = await client.get_participants(Scraper_Cloner_Source_Group_ID, filter=types.ChannelParticipantsAdmins)
            except Exception as e:
                admins=[]

            profile_label=0
            count_number=0
            last_sender_id = None
            for message in await client.get_messages(Scraper_Cloner_Source_Group_ID, limit=int(Scraper_Cloner_Number_Of_Messages)):
                try:                    # ...
                    scraped_message_text=message.message
                    new_string=""
                    sender=None
            
                    if scraped_message_text==None:
                        continue             
                    else:
                        
                        if len(str(scraped_message_text))>=Scraper_Cloner_Max_Message_Length:
                            print(Style.BRIGHT + Fore.RED +f"Long message message skipped: (Current length: {len(str(scraped_message_text))} characters, Your Settings: {Scraper_Cloner_Max_Message_Length} charactes)")
                            continue
                        else:
                            try:                                
                                sender=await message.get_sender()                        
                                if sender==None:
                                    print("Invalid Message Sender! Skipping Message")
                                    continue

                                if sender.bot:
                                    print("Status ",Scraper_Cloner_Bot_Message_Boolean)
                                    if Scraper_Cloner_Bot_Message_Boolean:
                                        pass
                                    else:
                                        print(Style.BRIGHT + Fore.RED +f"Bot message skipped according to your settings: "+Style.BRIGHT + Fore.RED +str(scraped_message_text[0:50]))
                                        continue
                                if sender in admins:                            
                                    if Scraper_Cloner_Admin_Messages_Boolean:
                                        pass
                                    else:
                                        print(Style.BRIGHT + Fore.RED +f"Admin message skipped according to your settings: "+Style.BRIGHT + Fore.RED +str(scraped_message_text[0:50]))
                                        continue
                            except Exception as e:
                                print(Style.BRIGHT + Fore.RED +"Error checking if message is from user or bot!: ",e)

                            print()

                            if scraped_message_text.startswith('/'):
                                print(Style.BRIGHT + Fore.RED +f"command message skipped") 
                                continue
                            if Scraper_Skip_Messages_WIth_Links==True:                            
                                def check_for_links_or_handles(text):
                                    # Regular expression pattern to match URLs
                                    url_pattern = r'(https?://[^\s]+|www\.[^\s]+)'
                                    # Regular expression pattern to match handles (e.g., @username)
                                    handle_pattern = r'@[A-Za-z0-9_]+'
                                    
                                    # Check if either pattern is found in the text
                                    if re.search(url_pattern, text) or re.search(handle_pattern, text):
                                        return True
                                    else:
                                        return False

                                if check_for_links_or_handles(str(scraped_message_text))==True:
                                    print(Style.BRIGHT + Fore.RED +f"Message with links skipped: "+Style.BRIGHT + Fore.RED +str(scraped_message_text[0:50]))
                                    continue



                            else:
                                print(Style.BRIGHT + Fore.YELLOW+f".....................................................")
                                print(Style.BRIGHT + Fore.YELLOW+f".....................................................")
                                profile_label=profile_label+1
                                print("\n"+message.message)
                                print(Style.BRIGHT + Fore.BLUE+"Analysing...")       
                                scraped_message_text=f'{scraped_message_text}'
                                scraped_message_text = scraped_message_text.replace('\r', ' ').replace('\n', ' ')
                                scraped_message_text.strip()
                                ' '.join(scraped_message_text.splitlines())

                                scrapdelay=random.randint(Scraper_Cloner_Min_Delay, Scraper_Cloner_Max_Delay)
                                 

                                x=random.randint(3, 6)

                                current_sender_id = sender.id
                                if current_sender_id == last_sender_id:
                                    scrapdelay = int(round(scrapdelay / 5))
                                    last_sender_id = current_sender_id                         
                                last_sender_id = current_sender_id

      
                                image_extension="" 



                                def save_new_record_wothout_delete_existing(path,xrecord):
                                    existing_content=None
                                    with open(path, "r", encoding='utf-8') as file_object:
                                        existing_content = file_object.read()

                                    with open(path, "w", encoding='utf-8') as file_object:
                                        # Write the new line at the beginning of the file
                                        file_object.write(xrecord + "\n")
                                        
                                        # Append the existing content after the new line
                                        file_object.write(existing_content)



    
                                if message.media:

                                    file_size = None
                                    file_size_mb=0

                                    if message.media:
                                        try:
                                            file_size_bytes = message.file.size
                                            file_size_mb = file_size_bytes / (1024 * 1024)  # Convert bytes to MB
                                            print(Style.BRIGHT + Fore.YELLOW+f"Media Size in MBs: {file_size_mb:.2f} MB")
                                        except Exception as e:
                                            print(Style.BRIGHT + Fore.RED+"Error getting File Size!, proceeding... ")

                                    if file_size_mb>=Scraper_Cloner_Max_Media:
                                        print(Style.BRIGHT + Fore.RED+f"Skipping Large Media of ({file_size_mb} mbs) - max media size setting ({Scraper_Cloner_Max_Media} mbs)")
                                        continue
                            

                                    count_number+=1
                                    count += 1
                                    if isinstance(message.media, MessageMediaPhoto):
                                        print(Style.BRIGHT + Fore.RED+str(count_number)+". "f"This message contains a photo")
                                        image_extension=".jpg"
                                        print(Style.BRIGHT + Fore.RED+f"Downloading Photo. Please wait...")
                                        await message.download_media(str(custom_media_folder)+"/"+str(count)+image_extension)
                                        print(Style.BRIGHT + Fore.BLUE+f"Photo saved: {count} {image_extension}")
                                            
                                    elif isinstance(message.media, MessageMediaDocument):
                                        print(Style.BRIGHT + Fore.RED+str(count_number)+". "f"This message contains a document")
                                        document = message.media.document  
                                        mime_type = document.mime_type.lower()

                                        image_extension = "."+str(mime_type.split('/')[-1])
                                        print(Style.BRIGHT + Fore.RED+f"Downloading DocumentMedia. Please wait...")

                                        await message.download_media(str(custom_media_folder)+"/"+str(count)+image_extension)
                                        print(Style.BRIGHT + Fore.GREEN+f"Download Done!")
                                        print(Style.BRIGHT + Fore.BLUE+f"Media Extension: {count} {image_extension}")
                                    else:
                                        continue

                                    
                                                                
                                    
     
                                    messagetype="imaged"
                                    #message.download_media("images/"+str(count)+image_extension)                                                                     
                                    imgg=str(count)+image_extension

                                    if str(sender.id) not in thislist:
                                        thislist.append(str(sender.id)) 
                                        if Scraper_Scrap_Sender_Names==True:

                                            thislist.append(str(sender.id))
                                            try:                                        
                                                save_new_record_wothout_delete_existing(chat_scraper_scraped_names_csv_file,f'{sender.first_name}')
                                                print(Style.BRIGHT + Fore.RED+f"Saved Sender Name Successfully in: {chat_scraper_scraped_names_csv_file}")
                                            except Exception as e:
                                                print(Style.BRIGHT + Fore.RED+f"Error saving Sender Name message: {e}")
                                                continue
                                            bio=None 
                                            if sender and hasattr(sender, 'about'):
                                                bio = f'{sender.about}'
                                            else:
                                                bio="NO BIO FOR THIS ACCOUNT"
                                            try:                                        
                                                save_new_record_wothout_delete_existing(chat_scraper_scraped_bio_csv_file,bio)
                                            except Exception as e:
                                                print(Style.BRIGHT + Fore.RED+f"Error saving Bio: {e}")
                                                continue
                                            pass
                                            try:   
                                                photo = await client.get_profile_photos(sender)
                                                if photo.total > 0:
                                                    profile_picture = await client.download_media(photo[0],file=chat_scraper_scraped_profile_photos_folder)
                                            except Exception as e:
                                                print (Style.BRIGHT + Fore.RED +f" Error In Saving User Photo "+str(e))

                                        



                                    sendingnow=int(thislist.index(str(sender.id)))+1                                                    

                                    #if sendingnow>accountlimit:
                                        #sendingnow=(sendingnow%accountlimit)+1 

                                    try:
                                        if sender.bot:
                                            if Scraper_Cloner_Bot_Message_Boolean:
                                                sendingnow="bot"
                                        elif sender in admins:
                                            if Scraper_Cloner_Admin_Messages_Boolean:
                                                sendingnow="admin"
                                        else:
                                            sendingnow=sendingnow

                                    except:
                                        pass                                                                    
                                    print(Style.BRIGHT + Fore.GREEN+"Sender Account: "+Style.BRIGHT + Fore.BLUE+str(sendingnow))
                                   


                                    if justcaption==True:
                                        printm="4--"+scraped_message_text+"--"+str(sendingnow)+"--"+str(scrapdelay)
                                    else:
                                        printm="3--"+scraped_message_text+"--"+imgg+"--"+str(sendingnow)+"--"+str(scrapdelay)


                                    try:
                                        save_new_record_wothout_delete_existing(custom_messages_txt_file,printm)
                                        print(Style.BRIGHT + Fore.GREEN+"Media Message added to file line")
                                    except Exception as e:
                                        print(Style.BRIGHT + Fore.RED+f"Error saving Mesdia message: {e}")
                                        continue
                        
                                    



   

                                elif message.is_reply:
                                    count_number+=1
                                    print(Style.BRIGHT + Fore.RED+str(count_number)+". "f"Reply Message")
                                    messagetype="replied"            
                                    replyto = await message.get_reply_message()
                                    if replyto and replyto.message:
                                            replymsggtxt_origi=replyto.message


                                            replymsggtxt=f'{replymsggtxt_origi}'
                                            replymsggtxt = replymsggtxt.replace('\r', ' ').replace('\n', ' ')
                                            replymsggtxt.strip()
                                            ' '.join(replymsggtxt.splitlines())
                                            filter(lambda x:x[0]!='@', replymsggtxt.split())                               



                                            if str(sender.id)not in thislist:
                                                thislist.append(str(sender.id)) 
                                                if Scraper_Scrap_Sender_Names==True:
                                                    try:                                        
                                                        save_new_record_wothout_delete_existing(chat_scraper_scraped_names_csv_file,f'{sender.first_name}')
                                                        print(Style.BRIGHT + Fore.RED+f"Saved Sender Name Successfully in: {chat_scraper_scraped_names_csv_file}")
                                                    except Exception as e:
                                                        print(Style.BRIGHT + Fore.RED+f"Error saving Sender Name message: {e}")
                                                        continue
                                                    bio=None 
                                                    if sender and hasattr(sender, 'about'):
                                                        bio = f'{sender.about}'
                                                    else:
                                                        bio="NO BIO FOR THIS ACCOUNT"
                                                    try:                                        
                                                        save_new_record_wothout_delete_existing(chat_scraper_scraped_bio_csv_file,bio)
                                                    except Exception as e:
                                                        print(Style.BRIGHT + Fore.RED+f"Error saving Bio: {e}")
                                                        continue
                                                    pass
                                                    try:   
                                                        photo = await client.get_profile_photos(sender)
                                                        if photo.total > 0:
                                                            clear_folder(chat_scraper_scraped_profile_photos_folder)
                                                            profile_picture = await client.download_media(photo[0],file=chat_scraper_scraped_profile_photos_folder)
                                                    except Exception as e:
                                                        print (Style.BRIGHT + Fore.RED +f" Error In Saving User Photo "+str(e)) 
            


                                            sendingnow=int(thislist.index(str(sender.id)))+1                                                    

                                            #if sendingnow>accountlimit:
                                                #sendingnow=(sendingnow%accountlimit)+1
                                            try:
                                                if sender.bot:
                                                    if Scraper_Cloner_Bot_Message_Boolean:
                                                        sendingnow="bot"
                                                elif sender in admins:
                                                    if Scraper_Cloner_Admin_Messages_Boolean:
                                                        sendingnow="admin"
                                                else:
                                                    sendingnow=sendingnow

                                            except:
                                                pass                                                 
                                            print(Style.BRIGHT + Fore.GREEN+"Sender Account: "+Style.BRIGHT + Fore.BLUE+str(sendingnow))
                                            #print("index of this old ender is: "+str(thislist.index(str(sender.id))))
                                            
                                            printm="2--"+scraped_message_text+"--"+replymsggtxt+"--"+str(sendingnow)+"--"+str(scrapdelay)
                                             

                                            try:
                                                save_new_record_wothout_delete_existing(custom_messages_txt_file,printm)
                                                print(Style.BRIGHT + Fore.GREEN+"Reply Message added to file line")
                                            except Exception as e:
                                                print(Style.BRIGHT + Fore.RED+f"Error saving Reply message: {e}")
                                                continue
                                            
                                            
                                
                                else:
                                    count_number+=1
                                    messagetype="normal message"
                                    print(Style.BRIGHT + Fore.RED+str(count_number)+". "+f"Normal Message")

                                    
                                    if str(sender.id)not in thislist:
                                        thislist.append(str(sender.id)) 
                                        if Scraper_Scrap_Sender_Names==True:
                                            try:                                        
                                                save_new_record_wothout_delete_existing(chat_scraper_scraped_names_csv_file,f'{sender.first_name}')
                                                print(Style.BRIGHT + Fore.RED+f"Saved Sender Name Successfully in: {chat_scraper_scraped_names_csv_file}")
                                            except Exception as e:
                                                print(Style.BRIGHT + Fore.RED+f"Error saving Sender Name message: {e}")
                                                continue
                                            bio=None 
                                            if sender and hasattr(sender, 'about'):
                                                bio = f'{sender.about}'
                                            else:
                                                bio="NO BIO FOR THIS ACCOUNT"
                                            try:                                        
                                                save_new_record_wothout_delete_existing(chat_scraper_scraped_bio_csv_file,bio)
                                            except Exception as e:
                                                print(Style.BRIGHT + Fore.RED+f"Error saving Bio: {e}")
                                                continue
                                            pass
                                            try:   
                                                photo = await client.get_profile_photos(sender)
                                                if photo.total > 0:
                                                    clear_folder(chat_scraper_scraped_profile_photos_folder)
                                                    profile_picture = await client.download_media(photo[0],file=chat_scraper_scraped_profile_photos_folder)
                                            except Exception as e:
                                                print (Style.BRIGHT + Fore.RED +f" Error In Saving User Photo "+str(e)) 

                                    sendingnow=int(thislist.index(str(sender.id)))+1                                                    

                                    #if sendingnow>accountlimit:
                                        #sendingnow=(sendingnow%accountlimit)+1




                                    try:
                                        if sender.bot:
                                            if Scraper_Cloner_Bot_Message_Boolean:
                                                sendingnow="bot"
                                        elif sender in admins:
                                            if Scraper_Cloner_Admin_Messages_Boolean:
                                                sendingnow="admin"
                                        else:
                                            sendingnow=sendingnow

                                    except:
                                        pass                                                                  
                                    print(Style.BRIGHT + Fore.GREEN+"Sender Account: "+Style.BRIGHT + Fore.BLUE+str(sendingnow))
                                    #print("index of this old ender is: "+str(thislist.index(str(sender.id))))

                                    printm="4--"+scraped_message_text+"--"+str(sendingnow)+"--"+str(scrapdelay)
 

                                    try:
                                        save_new_record_wothout_delete_existing(custom_messages_txt_file,printm)
                                        print(Style.BRIGHT + Fore.GREEN+"Text Message added to file line")
                                    except Exception as e:
                                        print(Style.BRIGHT + Fore.RED+f"Error saving Text message: {e}")
                                        continue
                                        
                except Exception as e:
                    print("Error\n",e)
                    continue          
            client.disconnect()


            print(Style.BRIGHT + Fore.RED+"-------------------------------------------------")
            print(Style.BRIGHT + Fore.RED+"Done! File Saved Succeesfully!!")
            print(Style.BRIGHT + Fore.RED+"-------------------------------------------------")
  

    source_scraper_account=None
    source_group_retrieved=None
    try:
        with open(scraper_settings_source_group_file_path, 'r') as file:
            source_group_retrieved = file.read()
    except:
        source_group_retrieved="Error"

    source_scraper_account=await check_if_listener_is_logged_in(scraper_account_phone_txt)

    phone_numbers_count = count_lines_in_file(sessions_phone_file)

    colorama.init(autoreset=True)
    print(Style.BRIGHT + Fore.GREEN + ''+Style.BRIGHT + Fore.BLUE+str(phone_numbers_count)+Style.BRIGHT + Fore.GREEN+" Accounts in phone.csv")
    print(Style.BRIGHT + Fore.GREEN + '                 [1] '+Style.BRIGHT + Fore.MAGENTA+'Login Scraper ('+str(source_scraper_account)+Style.BRIGHT + Fore.MAGENTA+")")
    print(Style.BRIGHT + Fore.GREEN + '                 [2] '+Style.BRIGHT + Fore.CYAN+'Source Group ('+Style.BRIGHT + Fore.BLUE+str(source_group_retrieved)+Style.BRIGHT + Fore.CYAN+")")
    print(Style.BRIGHT + Fore.GREEN + '                 [3] '+Style.BRIGHT + Fore.YELLOW+'Optional Settings')
    print(Style.BRIGHT + Fore.GREEN+ '                 [4] '+Style.BRIGHT + Fore.GREEN +'Start Chat Scraper')
    print(Style.BRIGHT + Fore.BLUE + '                 [0] '+Style.BRIGHT + Fore.RED +'Back]')
    TeleChoice = input(Style.BRIGHT + Fore.BLUE +'\nEnter your choice: ')

    try:
        TeleChoice=int(TeleChoice)
    except Exception as e:
        print("Error Occurred!\n",e)
        await chat_scraper_main_menu()



    if TeleChoice==1:
        await login_scraper_acc()
    elif TeleChoice==2:
        await set_source_group(scraper_account_phone_txt,scraper_account_session_folder,scraper_settings_source_group_file_path,chat_scraper_main_menu()) 
    elif TeleChoice==3:
        await update_and_display_settings(scraper_settings_file_path,chat_scraper_main_menu())
    elif TeleChoice==4:
        await dragonchatscraper()
    elif TeleChoice==0:
        await alex_main_menu()
    else:
        print("Invalid Input!")
        await chat_scraper_main_menu()
        















































async def fake_custom_chat_main_menu():
    print_section_title("Custom Chats")
    countp = 0
    countd = 0
    print(Style.BRIGHT + Fore.GREEN + "\nSTARTING CUSTOM CHATS...\n")


    Messages_file_path="./Messages_and_Media/"
    Media_folder_path="./Messages_and_Media/Messages.txt"
    Phone_list_csv="./Bulk_Accounts/phone.csv"
    Phone_list_session_folder="./Bulk_Accounts/sessions"
    Scraper_Phone_File="./Scraper_Account/scraper_account.txt"
    Scraper_Session_Folder="./Scraper_Account/scraper_session"


    

    async def fake_chatting():


            Custom_Cloner_Destination_Groups= None
            Custom_Cloner_Typing_Status= None
            Custom_Cloner_Bot_Account= None
            Custom_Cloner_Admin_Account= None
            Live_Cloner_Change_Names_Option= None
            Custom_Universal_Delay_Time=None


            useapi = apis[0]
            apidata = useapi.split()
            IdToUse = apidata[0]
            ApiToUse = apidata[1]



            try:        
                

                try:
                    with open(custom_settings_destination_group_filepath, 'r') as file:
                        Custom_Cloner_Destination_Groups = file.read().split(',')
                except Exception as e:
                    print("Could not find Destination Group Due To: ",e)
                    return None

                if Custom_Cloner_Destination_Groups==None:
                    print("Could not find Destination Group")
                    return None


                settings = load_settings(custom_settings_file_path)
                Custom_Cloner_Typing_Status = (get_value_by_key(settings, live_show_typing) or "")
                Custom_Cloner_Bot_Account = get_value_by_key(settings, live_custom_bot_acc) or None
                Custom_Cloner_Admin_Account = get_value_by_key(settings, live_custom_admin_acc) or None
                Custom_Cloner_Change_Names_Option = (get_value_by_key(settings, live_change_names) or "")
                Custom_Universal_Delay_Time = int(get_value_by_key(settings, fakechat_universal_delay) or 0)


                # Printing each value
                print(Style.BRIGHT + Fore.RED + "\nYour Current Custom Cloner Settings!\n")

                print(Style.BRIGHT + Fore.RESET + "Destination Groups: " + Style.BRIGHT + Fore.GREEN + ", ".join([f"{idx}. {group}" for idx, group in enumerate(Custom_Cloner_Destination_Groups, 1)]))
                print(Style.BRIGHT + Fore.RESET + "Show Typing Status: " + Style.BRIGHT + Fore.GREEN + str(Custom_Cloner_Typing_Status))
                print(Style.BRIGHT + Fore.RESET + "Custom Bot Account: " + Style.BRIGHT + Fore.GREEN + str(Custom_Cloner_Bot_Account))
                print(Style.BRIGHT + Fore.RESET + "Custom Admin Account: " + Style.BRIGHT + Fore.GREEN + str(Custom_Cloner_Admin_Account))
                print(Style.BRIGHT + Fore.RESET + "Change Account Names: " + Style.BRIGHT + Fore.GREEN + str(Custom_Cloner_Change_Names_Option))
                print(Style.BRIGHT + Fore.RESET + "Universal Delay (s): " + Style.BRIGHT + Fore.GREEN + str(Custom_Universal_Delay_Time) + "\n")



            except Exception as e:
                print("Error reading your Custom Cloner Settings due to ",e)
                return None


            ph = ""
            sendingphone = ""

            if Custom_Cloner_Bot_Account ==None:
                pass
            else:
                try:
                    phone=utils.parse_phone(Custom_Cloner_Bot_Account)
                    client = TelegramClient(f"{custom_bot_account_session_folder}/{phone}", IdToUse, ApiToUse)
                    try:
                        await client.connect()
                    except AuthKeyUnregisteredError:
                        print(Style.BRIGHT + Fore.RED + f"Bot Phone {phone} is not authorized. Skipping this account.")
                        pass
                    for g in Custom_Cloner_Destination_Groups:    
                        try:
                            result = await client(JoinChannelRequest(str(g)))
                            print(Style.BRIGHT + Fore.GREEN + f"Successfully joined with Custom Bot Account ({Custom_Cloner_Bot_Account}) - Groups ({Custom_Cloner_Destination_Groups})")
                        except Exception as e:
                            e=str(e) +" - "+str(g)
                            g = g.split('/')[-1]
                            if 'already a participant of the chat' in str(e):
                                print(Fore.GREEN+f"Already member public group: {g}: ")
                                continue
                        

                            result = await join_chat_private(client, g,e)
                            await asyncio.sleep(random.randint(1, 3))  # Wait between joining different groups

                except PhoneNumberBannedError:
                    print(Style.BRIGHT + Fore.RED + str(phone) + " has been banned")
                except SessionPasswordNeededError:
                    print(Style.BRIGHT + Fore.RED + "Two-step verification is enabled")
                except Exception as e:
                    print(Fore.RED + f"An error occurred while logging in: {e}")
                finally:
                    await client.disconnect()






            if Custom_Cloner_Admin_Account==None:
                pass
            else:
                try:
                    phone=utils.parse_phone(Custom_Cloner_Admin_Account)
                    client = TelegramClient(f"{custom_admin_account_session_folder}/{phone}", IdToUse, ApiToUse)
                    try:
                        await client.connect()
                    except AuthKeyUnregisteredError:
                        print(Style.BRIGHT + Fore.RED + f"Admin  Phone {phone} is not authorized. Skipping this account.")
                        pass
                    for g in Custom_Cloner_Destination_Groups:    
                        try:
                            result = await client(JoinChannelRequest(g))
                            print(Style.BRIGHT + Fore.GREEN + f"Successfully joined with Admin Bot Account ({Custom_Cloner_Admin_Account}) - Groups ({Custom_Cloner_Destination_Groups})")
                        except Exception as e:
                            e=str(e) +" - "+str(g)
                            g = g.split('/')[-1]
                            if 'already a participant of the chat' in str(e):
                                print(Fore.GREEN+f"Already member public group: {g}: ")
                                continue
                        

                            result = await join_chat_private(client, g,e)
                            await asyncio.sleep(random.randint(1, 3))  # Wait between joining different groups

                except PhoneNumberBannedError:
                    print(Style.BRIGHT + Fore.RED + str(phone) + " has been banned")
                except SessionPasswordNeededError:
                    print(Style.BRIGHT + Fore.RED + "Two-step verification is enabled")
                except Exception as e:
                    print(Fore.RED + f"An error occurred while logging in: {e}")
                finally:
                    await client.disconnect()

                



            async def selectaccount():

                accounts = {}
                if sessions_phone_file in os.listdir():
                    with open(sessions_phone_file, 'r', encoding='UTF-8') as f:
                        phones = f.read().replace(' ', '').split()
                    for phone in phones:
                        ph = utils.parse_phone(phone)
                        accounts[len(accounts) + 1] = ph

                
                str_list = []
                entity=""
                with open(sessions_phone_file, 'r')as f:
                    str_list = [row[0] for row in csv.reader(f)]
                    
        
                stored_entities = {}


                async def handle_entity_retrieval(client, destination_id, phone, stored_entities):
                    label = destination_id.replace("https://t.me/+", "").replace("t.me/+", "").replace("t.me/", "").replace("+", "")
                    entity_label = str(phone) + str(label)

                    # Function for converting channel data to Telethon entity
                    def channel_data_to_telethon_entity(entity_data):
                        if entity_data['_'] == 'Chat':
                            # For Chat, you only need the chat_id
                            return InputPeerChat(chat_id=entity_data['id'])
                        elif entity_data['_'] == 'Channel':
                            # For Channel, you need both id and access_hash
                            if 'access_hash' in entity_data:
                                return InputPeerChannel(channel_id=entity_data['id'], access_hash=entity_data['access_hash'])
                            else:
                                raise ValueError("Missing access_hash for Channel")
                        else:
                            raise ValueError("Unsupported entity type: " + str(entity_data['_']))

                    # Check if the entity is already stored
                    if entity_label in stored_entities:
                        entity_data = stored_entities[entity_label]
                        input_peer_channel = channel_data_to_telethon_entity(entity_data)
                        entity = await client.get_entity(input_peer_channel)
                    else:
                        entity = await client.get_entity(destination_id)
                        phone_entity = entity.to_dict()
                        stored_entities[entity_label] = phone_entity

                    return entity


                messagesent=False
                useapi=None
                SESSION_FOLDER=None
                phone=None

                def count_rows(csv_file_path):
                    with open(csv_file_path, 'r', newline='', encoding='utf-8') as csvfile:
                        csv_reader = csv.reader(csvfile)
                        row_count = sum(1 for row in csv_reader)
                    return row_count

                accountlimit = count_rows(sessions_phone_file)
                phone=None
                if os.path.isfile(custom_messages_txt_file):
                    with open(custom_messages_txt_file, 'r', encoding='UTF-8') as f:
                        for line in f.readlines():
                            
                            await asyncio.sleep(2)
                            print(Fore.YELLOW+"\nMessage: "+Fore.GREEN+str(f'{line}'))
                            for destination_group_link in Custom_Cloner_Destination_Groups:
                                messagesent=False
                               

                                line = line.strip()
                                splitdata = line.split("--")
                                messageselection = splitdata[0]

                                if messageselection == "4":
                                    try:
                                        print(Fore.YELLOW+"Sending Text Message to: "+Fore.GREEN+str(destination_group_link))
                                        messagetext = f'{splitdata[1]}'
                                        replymessagetext = "n/a"
                                        imagepath = "n/a"
                                        senderaccount = (splitdata[2])
                                        delayt = int(splitdata[3]) + int(Custom_Universal_Delay_Time)  # Make sure it's an int
                                       

                                        if str(senderaccount).lower()=="bot":
                                            print("Sending via bot: ",Custom_Cloner_Bot_Account)
                                            useapi = apis[0]
                                            senderaccount=0
                                            phone = Custom_Cloner_Bot_Account
                                            SESSION_FOLDER=custom_bot_account_session_folder
                                        elif str(senderaccount).lower()=="admin":
                                            print("Sending via admin: ",Custom_Cloner_Admin_Account)
                                            useapi = apis[0]
                                            senderaccount=0
                                            phone = Custom_Cloner_Admin_Account
                                            SESSION_FOLDER=custom_admin_account_session_folder

                                        else:
  
                                            try:
                                                senderaccount=int(senderaccount)
                                                try:
                                                    if senderaccount > accountlimit:
                                                        senderaccount = (senderaccount % accountlimit)
                                                except:
                                                    senderaccount = accountlimit


                                            except:
                                                senderaccount=0

                                            finally:
                                                phone = accounts.get(senderaccount, "")
                                                SESSION_FOLDER=sessions_folder
                                                try:
                                                    if (senderaccount + 1) <= number_of_api:
                                                        useapi = apis[senderaccount]
                                                    else:
                                                        useapi = apis[senderaccount % number_of_api]
                                                except Exception as e:
                                                    useapi = apis[0]


                                            pass
                                        
                                        apidata = useapi.split()
                                        IdToUse = apidata[0]
                                        ApiToUse = apidata[1]


                                        


                        
                                        phone = utils.parse_phone(phone)
                                        print(Style.BRIGHT + Fore.BLUE +f"Using {SESSION_FOLDER} :"+str(senderaccount)+Style.BRIGHT + Fore.BLUE +" - "+str(phone))

                                        
                                        print("Phone1: ",phone)



                                        client=TelegramClient(f"{SESSION_FOLDER}/{phone}", IdToUse, ApiToUse)
                                        await client.connect()
                                        if  await client.is_user_authorized():
                                            me = await client.get_me()
                                            
                                            
                                            if me:
                                                try:

                                                    print("Please wait...")



                                                    entity=await handle_entity_retrieval(client, destination_group_link, phone, stored_entities)
                                                    print(Style.BRIGHT + Fore.RED +"Sending Message...")
                                                    if   Custom_Cloner_Typing_Status==True:
                                                        await Send_Typing_Status_While_Sending_Message_To_Group(client,entity,2,6)
                                    
                                                                                     
                                                    await client.send_message(entity=entity, message=messagetext)
                                                    
                                                    print(Style.BRIGHT + Fore.GREEN +"Message Sent!")
                                                    messagesent=True

                                                except Exception as e:
                                                    print(f"Cant Send Normal Message: {e}")
                                                    continue
                                        else:
                                                print(Style.BRIGHT + Fore.RED+f'Session Login Failed!- {phone}')                                               
                                    
                                    except Exception as e:
                                        print(f"Encountered Error in Normal Msg Section! Skipping{e}")
                                        continue


                                                
                                            



                                elif messageselection == "3":
                                    try:

                                        print(Fore.YELLOW+"Sending Media Message to: "+Fore.GREEN+str(destination_group_link))
                                        messagetext = f'{splitdata[1]}'
                                        replymessagetext = "n/a"
                                        imagepath=f"{custom_media_folder}/"+str(splitdata[2])
                                        senderaccount = (splitdata[3])
                                        delayt = int(splitdata[4])+Custom_Universal_Delay_Time
    
                                        if str(senderaccount).lower()=="bot":
                                            print("Sending via bot: ",Custom_Cloner_Bot_Account)
                                            useapi = apis[0]
                                            senderaccount=0
                                            phone = Custom_Cloner_Bot_Account
                                            SESSION_FOLDER=custom_bot_account_session_folder
                                        elif str(senderaccount).lower()=="admin":
                                            print("Sending via admin: ",Custom_Cloner_Admin_Account)
                                            useapi = apis[0]
                                            senderaccount=0
                                            phone = Custom_Cloner_Admin_Account
                                            SESSION_FOLDER=custom_admin_account_session_folder

                                        else:
  
                                            try:
                                                senderaccount=int(senderaccount)
                                                try:
                                                    if senderaccount > accountlimit:
                                                        senderaccount = (senderaccount % accountlimit)
                                                except:
                                                    senderaccount = accountlimit


                                            except:
                                                senderaccount=0

                                            finally:
                                                SESSION_FOLDER=sessions_folder
                                                phone = accounts.get(senderaccount, "")
                                                try:
                                                    if (senderaccount + 1) <= number_of_api:
                                                        useapi = apis[senderaccount]
                                                    else:
                                                        useapi = apis[senderaccount % number_of_api]
                                                except Exception as e:
                                                    useapi = apis[0]

                                            pass
                                        apidata = useapi.split()
                                        IdToUse = apidata[0]
                                        ApiToUse = apidata[1]

 

                                        countz = 1

                                        


                            
                                        phone = utils.parse_phone(phone)
                                        print("Phone2: ",phone)

                
                                        print(Style.BRIGHT + Fore.BLUE +f"Using {SESSION_FOLDER} :"+str(senderaccount)+Style.BRIGHT + Fore.BLUE +" - "+str(phone))
                                        
                                        client=TelegramClient(f"{SESSION_FOLDER}/{phone}", IdToUse, ApiToUse)
                                        await client.connect()

                                        if  await client.is_user_authorized():
                                            me = await client.get_me()
    

                                            
                                            
                                            if me:
                                                try:
                                                    print("Please wait...")
                                                    entity=await handle_entity_retrieval(client, destination_group_link, phone, stored_entities)

               
                                                    print(Style.BRIGHT + Fore.RED +"Sending Media...")
                                                    if   Custom_Cloner_Typing_Status==True:
                                                        await Send_Typing_Status_While_Sending_Message_To_Group(client,entity,2,6)                         
                                                
                                                    await client.send_file(entity=entity, file=imagepath, caption=messagetext)
                                                    print(Style.BRIGHT + Fore.GREEN +"Media Sent!")
                                                    messagesent=True
                                                    
                      
                                                except Exception as e:
                                                    print(f"Cant Send Media: {e}")
                                                    continue

                                        else:
                                            print(Style.BRIGHT + Fore.RED +f'Session Login Failed!- {phone}') 

                                                

                                    except Exception as e:
                                        print(f"Encountered  in Media Send! Skipping{e}")
                                        continue            


                                elif messageselection == "2":
                                    try:

                                        print(Fore.YELLOW+"Sending Reply Message to: "+Fore.GREEN+str(destination_group_link))
                                        messagetext = f'{splitdata[1]}'
                                        replymessagetext = f'{splitdata[2]}'
                                        imagepath=""
                                        senderaccount = splitdata[3]
                                        delayt = int(splitdata[4])+Custom_Universal_Delay_Time



                                        if str(senderaccount).lower()=="bot":
                                            print("Sending via bot: ",Custom_Cloner_Bot_Account)
                                            useapi = apis[0]
                                            senderaccount=0
                                            phone = Custom_Cloner_Bot_Account
                                            SESSION_FOLDER=custom_bot_account_session_folder
                                        elif str(senderaccount).lower()=="admin":
                                            print("Sending via admin: ",Custom_Cloner_Admin_Account)
                                            useapi = apis[0]
                                            senderaccount=0
                                            phone = Custom_Cloner_Admin_Account
                                            SESSION_FOLDER=custom_admin_account_session_folder

                                        else:
  
                                            try:
                                                senderaccount=int(senderaccount)
                                                try:
                                                    if senderaccount > accountlimit:
                                                        senderaccount = (senderaccount % accountlimit)
                                                except:
                                                    senderaccount = accountlimit


                                            except:
                                                senderaccount=0

                                            finally:
                                                try:
                                                    SESSION_FOLDER=sessions_folder
                                                    phone = accounts.get(senderaccount, "")
                                                    if (senderaccount + 1) <= number_of_api:
                                                        useapi = apis[senderaccount]
                                                    else:
                                                        useapi = apis[senderaccount % number_of_api]
                                                except Exception as e:
                                                    useapi = apis[0]
                                            
                                        apidata = useapi.split()
                                        IdToUse = apidata[0]
                                        ApiToUse = apidata[1]
                               


                                        msgidd=""

                                        replytxt = replymessagetext
                                        


                                        countz = 1

                                       
                                        
                                        phone = utils.parse_phone(phone)
                                        print("Phon31: ",phone)

                                        print(Style.BRIGHT + Fore.BLUE +f"Using {SESSION_FOLDER} :"+str(senderaccount)+Style.BRIGHT + Fore.BLUE +" - "+str(phone))
                                  


                                        client=TelegramClient(f"{SESSION_FOLDER}/{phone}", IdToUse, ApiToUse)
                                        await client.connect()
                                        if  await client.is_user_authorized():
                                            me = await client.get_me()
                                            

                                            
                                            
                                            if me:
                                                print("Please wait...")
                                                entity=await handle_entity_retrieval(client, destination_group_link, phone, stored_entities)


                                                for message in await client.get_messages(entity, limit=10):
                                                    msgggg=message.message
                                                    if msgggg==None:
                                                        print()                                        
                                                    else:
                                                        if msgggg==replytxt:
                                                            try:
                                                                
                                                                msgidd=message.id
                                                                print(Style.BRIGHT + Fore.RED +"Sending Reply...")                                              
                                                                
                                                                if   Custom_Cloner_Typing_Status==True:
                                                                    await Send_Typing_Status_While_Sending_Message_To_Group(client,entity,2,6)
                                                                await client.send_message(entity=entity,reply_to=msgidd,message=messagetext)
                                                                print(Style.BRIGHT + Fore.GREEN +"Reply Sent!")
                                                                messagesent=True
                                                                break
                                    
                                                                
                                                            except Exception as e:
                                                                print(f"Cant Send Reply: {e}")
                                                                continue
                                        else:
                                            print(Style.BRIGHT + Fore.RED+f'Session Login Failed!- {phone}')                                                   
                                
                                                

                                    except Exception as e:
                                        print(f"Encountered  in Reply Send! Skipping{e}")
                                        continue

                                else:
                                    print("\nFormat Error Sending"+str(line))

                                    print("Moving to next")
                                    continue
                                await asyncio.sleep(random.randint(1, 3)) 
           

                            
                            try:
                                await client.disconnect()
                            except Exception as e:
                                print(e)
                                continue
                            if messagesent==True:
                                print(Style.BRIGHT + Fore.RED +"Waiting "+Style.BRIGHT + Fore.GREEN+str(delayt)+"s")
                                await asyncio.sleep(delayt)
                            else:
                                print(Style.BRIGHT + Fore.RED +"Waiting "+Style.BRIGHT + Fore.GREEN+str(5)+"s")
                                await asyncio.sleep(5)

                            print("\n")

                        print("Done Running Chats. Restarting?\n")
                
                        await selectaccount()


                else:
                    print("Check message files in absent or invalid")
            await selectaccount()


    destination_group_status=None
    try:
        with open(custom_settings_destination_group_filepath, 'r') as file:
            destination_group_status = file.read()
    except:
        destination_group_status="Error"


    print(Style.BRIGHT + Fore.GREEN + '                 [1] '+Style.BRIGHT + Fore.CYAN+'Destination Group ('+Style.BRIGHT + Fore.BLUE+str(destination_group_status)+Style.BRIGHT + Fore.CYAN+")")
    print(Style.BRIGHT + Fore.GREEN + '                 [2] '+Style.BRIGHT + Fore.YELLOW+'Optional Settings')
    print(Style.BRIGHT + Fore.GREEN + '                 [3] '+Style.BRIGHT + Fore.CYAN+'Join Destination with all sessions')
    print(Style.BRIGHT + Fore.GREEN + '                 [4] '+Style.BRIGHT + Fore.GREEN+'RUN FAKE CHATS')
    print(Style.BRIGHT + Fore.RED + '                 [0] ' + Style.BRIGHT + Fore.RED + 'Back')

    This_is_normal_Apexchat = input('\nEnter your choice: ')

    try:
        This_is_normal_Apexchat=int(This_is_normal_Apexchat)
    except Exception as e:
        print("Error Occurred!\n",e)
        await fake_custom_chat_main_menu()

    if This_is_normal_Apexchat==1:
        await set_destination_group(custom_settings_destination_group_filepath,fake_custom_chat_main_menu())
    elif This_is_normal_Apexchat==2:
        await update_and_display_settings(custom_settings_file_path,fake_custom_chat_main_menu())
    elif This_is_normal_Apexchat==3:
        await group_and_channel_joiner(custom_settings_destination_group_filepath,fake_custom_chat_main_menu())
    elif This_is_normal_Apexchat==4:
        await fake_chatting()
    elif This_is_normal_Apexchat==0:
        await alex_main_menu()
    else:
        print("Invalid Input!")
        await fake_custom_chat_main_menu()

                    





















































def save_phone_number_to_file(phone_number, file_name):
    with open(file_name, "w") as file:
        file.write(phone_number)
    print(f"Phone number saved to {file_name}")


async def Manage_Live_Cloner_Function():
    print_section_title("Accounts/Sessions")
    async def login_acc_menu():
        async def login_acc():
            listener_phone_number = None 
            
            async def main():


        

                def is_valid_phone_number(phone_number):
                    # Remove spaces from the input
                    phone_number =re.sub(r"\s+", "", phone_number)
                    
                    # Regular expression to match a valid phone number
                    pattern = r"^\+?[1-9]\d{9,14}$"
                    
                    return bool(re.fullmatch(pattern, phone_number))

                def get_valid_phone_number():
                    while True:
                        phone_number = input(Style.BRIGHT + Fore.RED+"Re-enter a valid phone number. No spaces allowed! "+Style.BRIGHT + Fore.BLUE+"\nEnter Phone Number: ")
                        
                        if is_valid_phone_number(phone_number):
                            return phone_number  # Return the valid phone number
                        else:
                            print(Style.BRIGHT + Fore.RED+"Invalid phone number. Please try again. No spaces allowed: "+Style.BRIGHT + Fore.BLUE+"\nEnter Phone Number: ")

                # Example usage
                valid_phone = get_valid_phone_number()
                listener_phone_number=str(valid_phone)

                listener_phone = utils.parse_phone(listener_phone_number)

                if number_of_api <= 0:
                    print(Style.BRIGHT + Fore.RESET + 'Please input API in API.txt\n')
                    input("Press Enter to Quit")
                    quit()

                api_select = random.randint(0, number_of_api - 1)
                useapi = apis[api_select]
                apidata = useapi.split()
                IdToUse = apidata[0]
                ApiToUse = apidata[1]
                print(Style.BRIGHT + Fore.BLUE + f"\nListener Login " + Style.BRIGHT + Fore.RED + f"{listener_phone_number} -" + Style.BRIGHT + Fore.WHITE + f" please wait...")

                asyncio.set_event_loop(asyncio.SelectorEventLoop())

                client = TelegramClient(f"{listener_account_session_folder}/{listener_phone}", IdToUse, ApiToUse)
                await client.connect()
                me = await client.get_me()

                phone_code_hash = None
                account_password = None
                if not me:
                    try:
                        result = await client.send_code_request(listener_phone) 
                        phone_code_hash = result.phone_code_hash
                        await asyncio.sleep(1)
                        otp_code = input(f'{listener_phone} - Enter Confirmation code: ')
                        await asyncio.sleep(2)
                        await client.sign_in(listener_phone, otp_code, phone_code_hash=phone_code_hash)
                        print(Style.BRIGHT + Fore.GREEN + f"\n{listener_phone} Logged in Successfully via OTP Code!")

                        save_phone_number_to_file(valid_phone,listener_account_phone_txt)
                        client.disconnect()


                    except SessionPasswordNeededError:
                        try:
                            account_password = input(Style.BRIGHT + Fore.RED + 'Password Required!\n' + Style.BRIGHT + Fore.BLUE + 'Enter the 2FA Password for: ')
                            await client.sign_in(listener_phone, password=account_password, phone_code_hash=phone_code_hash)
                            client.disconnect()
                            print(Style.BRIGHT + Fore.GREEN + f"\n{listener_phone} Logged in Successfully via Password!")
                            save_phone_number_to_file(valid_phone,listener_account_phone_txt)
                            client.disconnect()

                        except PasswordHashInvalidError:
                            print(Style.BRIGHT + Fore.RED + f"Invalid Password for {listener_phone}")
                            input('Press Enter to Quit!')
                            quit()
                        except Exception as e:
                            print(Style.BRIGHT + Fore.YELLOW + f"Error Signing {listener_phone} with password due to: {account_password}\n" + Style.BRIGHT + Fore.RED + str(e))
                            input('Press Enter to Quit!')

                        await asyncio.sleep(2)
                    except Exception as e:
                        print(Style.BRIGHT + Fore.YELLOW + f"Error Signing {listener_phone} in due to:\n" + Style.BRIGHT + Fore.RED + str(e))
                        input('Press Enter to Quit!')
                else:
                    print(Style.BRIGHT + Fore.GREEN + "Logged in Successfully - Saved Session File - " + str(listener_phone))
                    save_phone_number_to_file(valid_phone,listener_account_phone_txt)
                    client.disconnect()
                print(Style.BRIGHT + Fore.RESET + 'Done !')
                print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to go back')
                quit()

            await main()




        async def load_acc():
            async def load_sessions():
                global number_of_api
                if number_of_api <= 0:
                    print(Style.BRIGHT + Fore.RESET + 'Please input API in API.txt\n')
                    input("Press Enter to Quit")
                    quit()

                print(Style.BRIGHT + Fore.RED + f"WARNING! This action will replace contents of {listener_account_phone_txt}' ")

                print(Style.BRIGHT + Fore.GREEN + '[1] Continue')
                print(Style.BRIGHT + Fore.RED + '[2] Quit ')

                choice = int(input(Style.BRIGHT + Fore.BLUE + 'Enter your choice: '))

                if choice != 1:
                    quit()

                number_list = []
                extension = '*.session'
                session_files = glob.glob(os.path.join(listener_account_session_folder, extension))
                po = 1

                for session_file in session_files:
                    print(Style.BRIGHT + Fore.BLUE + "\nTrying to Load Session " + session_file)
                    session_name = str(session_file)
                    px = Path(session_file).stem

                    target_phon_str = str(px)

                    if (po + 1) <= number_of_api:
                        useapi = apis[po]
                    else:
                        if number_of_api == 0:
                            number_of_api = 1
                        useapi = apis[po % number_of_api]

                    apidata = useapi.split()
                    IdToUse = apidata[0]
                    ApiToUse = apidata[1]

                    phone = utils.parse_phone(target_phon_str)
                    if phone is None:
                        print(Style.BRIGHT + Fore.RED + "An error occurred while logging in: Session not valid. Make sure the session is named with its phone number!")
                    print(Style.BRIGHT + Fore.RED + " " + str(po) + Fore.CYAN + "-Checking Account: " + Fore.GREEN + str(phone))
                    po += 1

                    try:
                        client = TelegramClient(f"{listener_account_session_folder}/{phone}", IdToUse, ApiToUse)
                        await client.start(phone)
                        if await client.is_user_authorized():
                            print(Style.BRIGHT + Fore.BLUE + "Loaded Phone: " + target_phon_str + " successfully")
                            print(Style.BRIGHT + Fore.GREEN + "Session detected and user is authorized\n")

                            with open(scraper_account_phone_txt, 'w', encoding='UTF-8') as fn:
                                fn.write(f"{phone}\n")  # Write the phone number as a single line

                            print(Style.BRIGHT + Fore.GREEN + f"Successfully Saved ({phone}) Scraper SESSION NUMBER in {scraper_account_phone_txt}")
                            client.disconnect()
                            input("Press Enter to Exit")
                            return None

                        else:
                            print(Style.BRIGHT + Fore.RED + "Session not authorized\n")
                            time.sleep(random.randint(2, 6))
                        print()
                        done = True
                        await client.disconnect()
                    except PhoneNumberBannedError:
                        print(Style.BRIGHT + Fore.RED + str(phone) + " has been banned\n")
                    except SessionPasswordNeededError:
                        print(Style.BRIGHT + Fore.RED + "Two-step verification is enabled\n")
                    except Exception as e:
                        print(f"An error occurred while logging in: {e}\n")

                print(Style.BRIGHT + Fore.GREEN + "\nDone!!")
                print(Style.BRIGHT + Fore.YELLOW + 'Press Enter to go back')
                input()

            # Remove asyncio.run() and directly await load_sessions()
            await load_sessions()

        colorama.init(autoreset=True)
        print(Style.BRIGHT + Fore.RESET +"Checking current account...please wait")

        acc_status=await check_if_listener_is_logged_in_telethon(listener_account_phone_txt)
        print(Style.BRIGHT + Fore.RED+f"Current Account Status: "+f"{acc_status}\n")
        print(Style.BRIGHT + Fore.BLUE + '                 [1] '+Style.BRIGHT + Fore.GREEN+'Login New Listener (OTP)')
        print(Style.BRIGHT + Fore.BLUE + '                 [2] '+Style.BRIGHT + Fore.GREEN+'Load Listener (SESSION)')
        print(Style.BRIGHT + Fore.BLUE + '                 [3]'+Style.BRIGHT + Fore.RED+' Back]')
        TeleChoice = (input('\nEnter your choice: '))

        try:
            TeleChoice=int(TeleChoice)
        except Exception as e:
            print("Error Occurred!\n",e)
            await login_acc_menu()
        if TeleChoice==1:
            await login_acc() 
        elif TeleChoice==2:
            await load_acc()       
        elif TeleChoice==3:
            await Manage_Live_Cloner_Function()
       
        else:
            print(Style.BRIGHT + Fore.RED +'\nInvalid Input!')
            await login_acc_menu()





   





    async def Live_Cloner_Running_Function():

        print(Style.BRIGHT + Fore.GREEN + "\nLIVE CHAT CLONER STARTING...")


        Live_Cloner_Source_Group_Link=None
        Destination_Group_Links_List=[]
        Live_Cloner_Listener_Account = None


        Live_Cloner_Bot_Message_Boolean = None
        Live_Cloner_Admin_Messages_Boolean = None
        Live_Cloner_Max_Message_Length = None
        Live_Cloner_Skip_All_Messages_with_links = None

        Live_Cloner_Typing_Status= None
        Live_Cloner_Bot_Account= None
        Live_Cloner_Admin_Account= None
        Live_Cloner_Change_Names_Option= None
        Live_Cloner_Replace_Link_Boolean=False
        Live_Cloner_Replacement_Link= None
        Live_Cloner_Replace_Words= None
        Live_Cloner_Source_Group_Link=None


        with open(livesettings_source_group_file_path, 'r') as file:
            Live_Cloner_Source_Group_Link = file.read()
        if Live_Cloner_Source_Group_Link==None or str(Live_Cloner_Source_Group_Link)=="":
            print(Style.BRIGHT + Fore.RED +f"No Source Group/Channel Detected in {livesettings_source_group_file_path}! Please set source group before proceeding!")
            return None


        with open(livesettings_destination_group_file_path, 'r') as file:
            Destination_Group_Links_List = file.read().split(',')
        Destination_Group_Links_List = [link.strip() for link in Destination_Group_Links_List if link.strip()]
        if Destination_Group_Links_List==None or str(Destination_Group_Links_List)=="":
            print(Style.BRIGHT + Fore.RED +f"No Destination Group/Channel Detected in {livesettings_destination_group_file_path}! Please set source group before proceeding!")
            return None

        with open(listener_account_phone_txt, 'r') as file:
            Live_Cloner_Listener_Account = file.read().split(',')
        if Live_Cloner_Listener_Account==None or str(Live_Cloner_Listener_Account)=="":
            print(Style.BRIGHT + Fore.RED +f"No Listener Account in {listener_account_phone_txt}! Please set Listener Account before proceeding!")
            return None

        try:
            settings = load_settings(livesettings_file_path)
            split_result = Live_Cloner_Source_Group_Link.split('--')
            first_element = split_result[0]
            Live_Cloner_Source_Group_Name = split_result[1]
            
            if first_element.isnumeric():
                Live_Cloner_Source_Group_Link = int("-100" + first_element)
            else:
                print(Style.BRIGHT + Fore.RED + "Could not find Source Group ID from: ", Live_Cloner_Source_Group_Name)
                return None

            Live_Cloner_Bot_Message_Boolean = (get_value_by_key(settings, live_clone_bot_messages) or "")
            Live_Cloner_Admin_Messages_Boolean = (get_value_by_key(settings, live_clone_admin_messages) or "")
            Live_Cloner_Max_Message_Length = int(get_value_by_key(settings, live_max_message_length) or 0)
            Live_Cloner_Skip_All_Messages_with_links = (get_value_by_key(settings, live_skip_msg_with_links) or "")
            Live_Cloner_Typing_Status = (get_value_by_key(settings, live_show_typing) or "")
            Live_Cloner_Bot_Account = get_value_by_key(settings, live_custom_bot_acc) or "None"
            Live_Cloner_Admin_Account = get_value_by_key(settings, live_custom_admin_acc) or "None"
            Live_Cloner_Change_Names_Option = (get_value_by_key(settings, live_change_names) or "")
            Live_Cloner_Replace_Link_Boolean = (get_value_by_key(settings, live_replace_links_boolean) or "")
            Live_Cloner_Replacement_Link = get_value_by_key(settings, livecloner_new_replacement_link) or "default_replacement_link"
            Live_Cloner_Replace_Words = get_value_by_key(settings, live_replace_words) or "default_replacement_words"

            # Printing each value
            print(Style.BRIGHT + Fore.RED + "\nYour Current Live Chat Cloner Settings!")
            print(Style.BRIGHT + Fore.RESET + "Listener Account: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Listener_Account or "None"))
            print(Style.BRIGHT + Fore.RESET + "Source group: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Source_Group_Name) + 
                  " (ID: " + str(Live_Cloner_Source_Group_Link) + ")")
            print(Style.BRIGHT + Fore.RESET + "Clone Bot Messages: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Bot_Message_Boolean))
            print(Style.BRIGHT + Fore.RESET + "Clone Admin Messages: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Admin_Messages_Boolean))
            print(Style.BRIGHT + Fore.RESET + "Max Message Length: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Max_Message_Length))
            print(Style.BRIGHT + Fore.RESET + "Skip All Messages with links: " + Style.BRIGHT + Fore.YELLOW + str(Live_Cloner_Skip_All_Messages_with_links))
            print(Style.BRIGHT + Fore.RESET + "Show Typing Status: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Typing_Status))
            print(Style.BRIGHT + Fore.RESET + "Custom Bot Account: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Bot_Account))
            print(Style.BRIGHT + Fore.RESET + "Custom Admin Account: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Admin_Account))
            print(Style.BRIGHT + Fore.RESET + "Change Account Names to Match Source Group: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Change_Names_Option))
            print(Style.BRIGHT + Fore.RESET + "Replace All Links: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Replace_Link_Boolean))
            print(Style.BRIGHT + Fore.RESET + "Replacement Link: " + Style.BRIGHT + Fore.BLUE + str(Live_Cloner_Replacement_Link))
            print(Style.BRIGHT + Fore.RESET + "Replace Specific Words: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Replace_Words) + "\n")

        except Exception as e:
            print(Style.BRIGHT + Fore.RED + "Error reading your Live Cloner Settings due to ", e)
            return None



        try:
            sendingphone = ""            
            accounts = {}
            if os.path.exists(sessions_phone_file):
                with open(sessions_phone_file, 'r', encoding='UTF-8') as f:
                    phones = f.readlines()  # Read lines instead of using read().replace().split()      
                if not phones:
                    print(Style.BRIGHT + Fore.RED +f" You dont have any accounts added in {sessions_phone_file}")
                    return None
                    
                else:
                    for i, phone in enumerate(phones, start=1):
                        ph = utils.parse_phone(phone.strip())  # Strip newline characters and whitespace
                        accounts[i] = ph
                phone_numbers_count = count_lines_in_file(sessions_phone_file)
                print(Style.BRIGHT + Fore.GREEN +f"Accounts Path: {sessions_phone_file}! Accounts: "+Style.BRIGHT + Fore.BLUE +str(phone_numbers_count)+f" Phone Numbers")


        
            else:
                print(Style.BRIGHT + Fore.RED +"Could not find accounts file - "+str(sessions_phone_file))
                return None

            num_phones_added = len(accounts)
            if num_phones_added<1:
                print(Style.BRIGHT + Fore.RED +"0 accounts found! - "+str(sessions_phone_file))
                return None
        except Exception as e:
            print(Style.BRIGHT + Fore.RED+"Error in  starting live cloner project `"+str(e)+"`")





        listener_phone = str(Live_Cloner_Listener_Account[0])        
        listener_phone = utils.parse_phone(listener_phone)
        useapi = apis[0]
        apidata = useapi.split()
        IdToUse = apidata[0]
        ApiToUse = apidata[1]
        global  Saved_Members
        Chatted_Members = []      
        admins=[]



        SESSION_FOLDER = listener_account_session_folder
        os.makedirs(SESSION_FOLDER, exist_ok=True)

        source_entity=None
        listener_client = TelegramClient(f"{SESSION_FOLDER}/{listener_phone}", IdToUse, ApiToUse)
        try:
            await listener_client.connect()
        except Exception as e:
            print(Style.BRIGHT + Fore.RED +"Error Connecting your Telegram Account"+str(listener_phone)+" due to\n `"+str(e)+"`\nPlease try again!")
            return None
        if await listener_client.is_user_authorized():
            try:
                try:
                    print(Style.BRIGHT + Fore.GREEN + "Getting Source Entity: " + Style.BRIGHT + Fore.GREEN + str(Live_Cloner_Source_Group_Name) + 
                          " (ID: " + str(Live_Cloner_Source_Group_Link) + ")")
                    source_entity = await listener_client.get_entity(Live_Cloner_Source_Group_Link)
                except Exception as e:
                    print(Style.BRIGHT + Fore.RED + "Couldn't find your source group entity due to: ", e)
                    print("Cloner Stopped")
                    return None

                print("Source Entity Found...proceeding")
                if source_entity is None:
                    print(f"Couldnt Find Entity for your source group")
                try:
                    admins = await listener_client.get_participants(source_entity, filter=types.ChannelParticipantsAdmins)
                except Exception as e:
                    admins=[]
                Live_Cloner_Media_Path = livecloner_temp_media_folder
                os.makedirs(Live_Cloner_Media_Path, exist_ok=True) 
                message_queue = Queue()

                async def handle_new_message(event):
                    sender = await event.get_sender()
                    message_sender_id=None
                    try:
                        message_sender_id = sender.id
                    except:
                        pass
                    if message_sender_id==None:
                        return None

                    if sender is None:
                        print(Style.BRIGHT + Fore.RED +f"Invalid Message Received!\nError: {e}")
                        return None

                   
                    message_contents = event
                    await message_queue.put((event.sender_id, event))

                    await process_message_queue_thread()

                lock = asyncio.Lock()

                async def process_message_queue_thread():
                    global processing
                    try:
                        # Check if processing is not already running
                        if not processing:
                            processing = True

                            # Process messages while the queue is not empty
                            while not message_queue.empty():
                                async with lock:
                                    # Get the next message from the queue
                                    message_sender_id, message_contents = await message_queue.get()
                                    try:
                                        # Replace with your actual message processing logic
                                        await clone_new_message(message_sender_id, message_contents)
                                    except Exception as e:
                                        print(Style.BRIGHT + Fore.RED +f"Error Processing Message: {e}")
                                    finally:
                                        print(Style.BRIGHT + Fore.MAGENTA +f"Waiting for new messages! /stop_project")

                            # Reset the processing flag when done
                            processing = False

                    except Exception as e:
                        print(Style.BRIGHT + Fore.GREEN +f"Error Processing Message: {e}")
                        return None


             

                async def clone_new_message(sender_id,sent_msg):
                    SESSION_FOLDER="./sessions"
                    try:
                        print(Style.BRIGHT + Fore.BLUE +"\n\nProcessing Message: ",sent_msg.message.text[0:100])
                    except:
                        print(Style.BRIGHT + Fore.BLUE +"\n\nProcessing Media...")
                        pass

                    try:
                        sender = await sent_msg.get_sender()
                        if sender is None:
                            print(Style.BRIGHT + Fore.RED +f"Invalid message (Sender is None) ")
                            return None 

                        message_sender_id = sender.id
                        if message_sender_id is None:
                            print(Style.BRIGHT + Fore.RED +f" Invalid message (Sender is None)")
                            return None

                        


                        msg_length=len(str(sent_msg.message.text))
                        try:
                            max_msg_length=int(Live_Cloner_Max_Message_Length)
                            if max_msg_length==None or max_msg_length==0:
                                max_msg_length=1000
                        except:
                            max_msg_length=51000


                        if len(str(sent_msg.message.text))>int(max_msg_length):
                            print(Style.BRIGHT + Fore.RED +f"Long message message skipped: (Current length: {len(str(sent_msg.message.text))} characters, Your Settings: {max_msg_length} charactes)")
                            return None

              
                        if sender.bot:
                            if Live_Cloner_Bot_Message_Boolean:
                                pass
                            else:
                                print(Style.BRIGHT + Fore.RED +f"Bot message skipped")
                                return None 
                        if sender in admins:                            
                            if Live_Cloner_Admin_Messages_Boolean:
                                pass
                            else:
                                print(Style.BRIGHT + Fore.RED +f"Admin message skipped:")



                        if Live_Cloner_Skip_All_Messages_with_links==True:
                            
                            def check_for_links_or_handles(text):
                                # Regular expression pattern to match URLs
                                url_pattern = r'(https?://[^\s]+|www\.[^\s]+)'
                                # Regular expression pattern to match handles (e.g., @username)
                                handle_pattern = r'@[A-Za-z0-9_]+'
                                
                                # Check if either pattern is found in the text
                                if re.search(url_pattern, text) or re.search(handle_pattern, text):
                                    return True
                                else:
                                    return False

                            if check_for_links_or_handles(sent_msg.message.text)==True:
                                print(Style.BRIGHT + Fore.RED +f"Message with links skipped")
                                return None
                    except Exception as e:
                        print(Style.BRIGHT + Fore.RED +f' Error with message for'+str(e)+'`')
                        return None




                    pending_message=sent_msg.message.text
                    event=sent_msg

                    message_text=sent_msg.message.text


                    if Live_Cloner_Replace_Link_Boolean==True and  Live_Cloner_Replacement_Link is not None and str(Live_Cloner_Replacement_Link)!="" :
                        def replace_links(text, replacement):
                            url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
                            # Replace all URLs with the specified replacement
                            replaced_text = re.sub(url_pattern, replacement, text)
                            return replaced_text
                        message_text = replace_links(str(message_text),str(Live_Cloner_Replacement_Link))




                    if Live_Cloner_Replace_Words is not None:
                        try:
                            text_string = str(Live_Cloner_Replace_Words)

                            # Split the text string by lines
                            lines = text_string.strip().split(',')

                            # Create a dictionary of replacements, converting keys to lowercase
                            replacements = {}
                            for line in lines:
                                if '==' in line:
                                    key, value = map(str.strip, line.split('==', 1))  # Split and strip spaces
                                    replacements[key.lower()] = value  # Store with lowercase key

                            # Function to replace text in a case-insensitive manner
                            def replace_in_text(original_text, replacements):
                                # Create a regular expression pattern with all keys
                                pattern = re.compile('|'.join(re.escape(key) for key in replacements.keys()), re.IGNORECASE)

                                def replace_match(match):
                                    matched_word = match.group(0)
                                    lower_word = matched_word.lower()
                                    return replacements.get(lower_word, matched_word)

                                return pattern.sub(replace_match, original_text)

                            # Perform replacements on the original message text
                            message_text = replace_in_text(message_text, replacements)
                        except Exception as e:
                            print(e)
                            pass


                    
                    
                    ph = ""
                    sendingphone = ""
                    accounts = {}
                    if os.path.exists(sessions_phone_file):
                        with open(sessions_phone_file, 'r', encoding='UTF-8') as f:
                            phones = f.read().replace(' ', '').split()
                        
                        for phone in phones:
                            ph = utils.parse_phone(phone)
                            accounts[len(accounts) + 1] = ph                    

                    

                    def count_rows(csv_file_path):
                        with open(csv_file_path, 'r', newline='', encoding='utf-8') as csvfile:
                            csv_reader = csv.reader(csvfile)
                            row_count = sum(1 for row in csv_reader)
                        return row_count

                    number_of_rows = count_rows(sessions_phone_file)
                    accountlimit=number_of_rows
                    

                    
                   

                    if str(sender_id) in Chatted_Members:
                        sending_account = Chatted_Members.index(str(sender_id)) + 1
                    else:
                        Chatted_Members.append(str(sender_id))
                        sending_account = len(Chatted_Members)

                    '''print("Acc Limit: "+str(accountlimit))
                    print("Sending Acc: "+str(sending_account))

                    print("\n\nbefore")

                    

                    if sending_account > accountlimit:
                        sending_account = (sending_account % accountlimit)
                    if sending_account == 0:
                        sending_account = accountlimit

                    
              

                    print("Acc Limit: "+str(accountlimit))
                    print("Sending Acc: "+str(sending_account))'''


                    if (sending_account + 1) <= number_of_api:
                        useapi = apis[sending_account]
                    else:
                        useapi = apis[sending_account % number_of_api]
                    apidata = useapi.split()
                    IdToUse = apidata[0]
                    ApiToUse = apidata[1]
                    

                    phone_tosend = None
                    
                    if sent_msg.sender.bot:
                        if Live_Cloner_Bot_Message_Boolean==True and Live_Cloner_Bot_Account is not None and str(Live_Cloner_Bot_Account)!="":
                            phone_tosend=str(Live_Cloner_Bot_Account)
                            SESSION_FOLDER = custom_bot_account_session_folder

                    elif sent_msg.sender in admins:
                        if Live_Cloner_Admin_Messages_Boolean==True and Live_Cloner_Admin_Account is not None and str(Live_Cloner_Admin_Account)!="":
                            phone_tosend=str(Live_Cloner_Admin_Account)
                            SESSION_FOLDER = custom_admin_account_session_folder
                    else:

                        SESSION_FOLDER = sessions_folder
                        try:
                            sending_account=int(sending_account)
                            if sending_account > accountlimit:
                                sending_account = (sending_account % accountlimit)
                            if sending_account == 0:
                                sending_account = accountlimit
                        except:
                            sending_account = accountlimit
                        finally:
                            phone_tosend=accounts.get(sending_account, "")        
                    phone_tosend = utils.parse_phone(phone_tosend)




                    xtext=message_text [0:40]
                    client=TelegramClient(f"{SESSION_FOLDER}/{phone_tosend}", IdToUse, ApiToUse)
                    await client.connect()

                    if await client.is_user_authorized():
                        print(
                            Style.BRIGHT + Fore.BLUE +"Trying clone with account: " + str(sending_account) + str(phone_tosend)+
                            " Message: " + str(xtext)
                        )

                        if xtext is None or str(xtext)=="" or str(xtext)=="None":
                            xtext="Photo/Video"                       
                        
                        try:
                            print("Your Destination Links: ",Destination_Group_Links_List)

                            save_account_number=0
                            if str(sender_id) in Saved_Members:
                                save_account_number= Saved_Members.index(str(sender_id)) + 1
                                print('old member')
                            else:
                                print("new member")
                                Saved_Members.append(str(sender_id))
                                save_account_number = len(Saved_Members)

                                if Live_Cloner_Change_Names_Option==True:
                                    if save_account_number<=num_phones_added:
                                        Live_Cloner_ProFile_Photo_Path = livecloner_temp_profile_folder
                                        os.makedirs(Live_Cloner_Media_Path, exist_ok=True) 

                                        print(Style.BRIGHT + Fore.MAGENTA +f"⏳ _Changing Profile of  - _" + str(sending_account) + ":  `" + str(phone_tosend)+"`")
                                        time.sleep(2)
                                        sender = await sent_msg.get_sender()
                                        first_name = sender.first_name
                                        last_name = sender.last_name
                                        if last_name is not None:
                                            full_name = f"{first_name} {last_name}"
                                        else:
                                            full_name = first_name
                                        try:
                                            await client(UpdateProfileRequest(first_name= full_name,last_name=""))
                                            print(Style.BRIGHT + Fore.GREEN +f'Successfully changed name for_ `'+str(phone_tosend)+'`'+"New: `"+str(full_name)+"`")
                                        except Exception as e:
                                            print(Style.BRIGHT + Fore.RED +f'Error Changing name for_ `'+str(phone_tosend)+'`'+"Error: `"+str(e)+"`")
                                        time.sleep(2)
                                        try:   
                                            photo = await listener_client.get_profile_photos(sender)
                                            if photo.total > 0:
                                                clear_folder(Live_Cloner_ProFile_Photo_Path)
                                                profile_picture = await listener_client.download_media(photo[0],file=Live_Cloner_ProFile_Photo_Path)
                                                try:
                                                    result = await client(functions.photos.UploadProfilePhotoRequest(file=await client.upload_file(profile_picture)))
                                                    print(Style.BRIGHT + Fore.GREEN +f'Successfully updated profile picture')
                                                except Exception as e:
                                                    print(Style.BRIGHT + Fore.RED +f'Error updating Profile picture for'+str(e))
                                        except Exception as e:
                                            print (Style.BRIGHT + Fore.RED +f" Error In Cloning User Photo and Name!"+str(e))      


                            for destination_id in Destination_Group_Links_List:
                                print(Fore.YELLOW+"Current Destination Group/Channel: "+Fore.GREEN+str(destination_id))
                                #entity=await Get_Group_Entity(client,str(phone_tosend),stored_entities,destination_id )
                                label=destination_id.replace("https://t.me/+", "" )
                                label=label.replace("t.me/+", "" )
                                label=label.replace("t.me/", "" )
                                label=label.replace("+", "" )
                                entity_label=str(phone)+str(label)
                                def channel_data_to_telethon_entity(channel_data):
                                    if entity_data['_'] == 'Chat':
                                        # For Chat, you only need the chat_id
                                        return InputPeerChat(chat_id=entity_data['id'])
                                    elif entity_data['_'] == 'Channel':
                                        # For Channel, you need both id and access_hash
                                        if 'access_hash' in entity_data:
                                            return InputPeerChannel(channel_id=entity_data['id'], access_hash=entity_data['access_hash'])
                                        else:
                                            raise ValueError("Missing access_hash for Channel")
                                    else:
                                        raise ValueError("Unsupported entity type: " + str(entity_data['_'])) 
                                if entity_label in stored_entities:
                                    entity_data=stored_entities[entity_label]

                                    input_peer_channel=channel_data_to_telethon_entity(entity_data)
                                    entity = await client.get_entity(input_peer_channel)
                                    
                                else:
                                    entity = await client.get_entity(destination_id)
                                    phone_entity = entity.to_dict()
                                    stored_entities[entity_label] = phone_entity


                                






                                if event.media:
                                    captiontxt=None
                                    if event.text is not None or event.text=="":
                                        captiontxt=event.text
                                    else:
                                        captiontxt=message_text
                                    try:
                                        clear_folder(Live_Cloner_Media_Path)
                                        media_file= await event.download_media(Live_Cloner_Media_Path)
           
                                        try:
                                            if media_file is not None and media_file.endswith('.webm'):
                                                print(
                                                    Style.BRIGHT + Fore.YELLOW +"Invalid Media "
                                                )
                                                                                                                                     
                                                continue
                                        except:
                                            pass                                                                        
                                        await client.send_message(entity, file=media_file,message=captiontxt,force_document=False)
                                                                                      

                                        print(Style.BRIGHT + Fore.GREEN +f"✔️ Media Message Cloned Successfully")
                                        continue
                                    except Exception as e:
                                        try:
                                            await client.send_message(entity, file=event.media,message=captiontxt,force_document=False)                                                                                       
                                            await Send_reply(update,context,text__string_to_send,None)
                                            print(Style.BRIGHT + Fore.GREEN +f"✔️ Media Message Cloned Successfully ")
                                            continue
                                        except:
                                            print(Style.BRIGHT + Fore.RED +"An error occurred while attempting to send the Media/Sticker\n"+str(e))                        
                                            continue



                                elif sent_msg.is_reply:
                                    try:
                                        sender=""
                                        replyto = await sent_msg.get_reply_message()
                                        if replyto and replyto.message:                                                                          
                                            replymsggtxt=replyto.message
                                            replymsgg_id=replyto.id
                                            #replymessageid=replymsgg.id                           r                                         
                                            sender=await sent_msg.get_sender()  
                                            for xmessage in await client.get_messages(entity, limit=20):
                                                msgggg=xmessage.message
                                                if msgggg==None:
                                                    continue                                       
                                                else:
                                                    if msgggg==replymsggtxt:                                                     
                                                        try:                                                        
                                                            msgidd=xmessage.id 

                                                            if   Live_Cloner_Typing_Status==True:
                                                                await Send_Typing_Status_While_Sending_Message_To_Group(client,entity,2,6)  
                                                            await client.send_message(entity=entity,reply_to=msgidd,message=message_text)
                                                            print(Style.BRIGHT + Fore.GREEN +f"✔️ Reply Message Cloned Successfully")
                                                            continue
                    
            
                                                            
                                                        except Exception as e:
                                                            try:
                                                                await client.send_message(entity=entity,reply_to=msgidd,message=sent_msg.message.text)
                                                                print(Style.BRIGHT + Fore.GREEN +"Successfully cloned reply message ")                                                       
                                                                continue
                                                            except Exception as e:
                                                                print(Style.BRIGHT + Fore.RED +"An error occurred  for project while attempting to send the reply message\nError: \n"+str(e)) 
                                                                continue
                                            print(Style.BRIGHT + Fore.YELLOW +"Message being replied to in source not present in destination not found! Skipping")
                                            continue
                                        else:
                                            print(Style.BRIGHT + Fore.YELLOW +"Message being replied to in source not present in destination not found! Skipping")
                                            continue
                                    except Exception as e: 
                                        print(Style.BRIGHT + Fore.RED +"Error Cloning Reply  for project \nError:\n"+str(e))                               
                                        continue

                                    
                                else:                                 
                                    try:

                                        if   Live_Cloner_Typing_Status==True:
                                            await Send_Typing_Status_While_Sending_Message_To_Group(client,entity,2,6)                                                                       
                                        await client.send_message(entity=entity, message=message_text)           
                                        print(Style.BRIGHT + Fore.GREEN +"Successfully cloned text message")
                                        continue

                                    except Exception as e:
                                        print(Style.BRIGHT + Fore.RED +f"Error in  Text Message, project\nError\n{e}")
                                        continue



                        except Exception as error:
                            try:
                                await client.disconnect()
                            except:
                                pass
                            print(Style.BRIGHT + Fore.RED +f"Error in  Media Message\nError\n{error}")
                            return None
                        finally:
                            try:
                                await client.disconnect()  
                            except:
                                pass
                    else:
                        try:
                            await client.disconnect()
                        except:
                            pass
                        print(Style.BRIGHT + Fore.RED +f"Error: Listener Account {phone_tosend}  not logged in! \n")
                        return None

                print(
                    Style.BRIGHT + Fore.GREEN + f"\n\nSource: " + Style.BRIGHT + Fore.YELLOW + str(Live_Cloner_Source_Group_Name) + 
                    " (ID: " + str(Live_Cloner_Source_Group_Link) + ")\n" +
                    Style.BRIGHT + Fore.YELLOW + "Destination Groups:\n" +
                    ''.join([Style.BRIGHT + Fore.BLUE + f"- {group}\n" for group in Destination_Group_Links_List]) +
                    Style.BRIGHT + Fore.BLUE + f"Account: " + Style.BRIGHT + Fore.GREEN + f"{Live_Cloner_Listener_Account[0]}\n" +
                    Style.BRIGHT + Fore.YELLOW + f"Number of Accounts: " + Style.BRIGHT + Fore.MAGENTA + f"{num_phones_added}"
                )



                print(Style.BRIGHT + Fore.GREEN +f"Connected Succeesfully! \nSource Group/Channel: {Live_Cloner_Source_Group_Name}\n"
                      "Waiting for new messages... \n")

                

                # Initialize state variables
                local_pts = 0
                local_seq = 0

                async def fetch_initial_state():
                    nonlocal local_pts, local_seq
                    state = await listener_client(GetStateRequest())
                    local_pts = state.pts
                    local_seq = state.seq

                async def handle_new_message_update(message):
                    nonlocal local_pts, local_seq

                    if hasattr(message, 'pts') and hasattr(message, 'pts_count'):
                        if local_pts + message.pts_count == message.pts:
                            local_pts = message.pts
                        elif local_pts + message.pts_count < message.pts:
                            await fetch_missing_updates()

                async def fetch_missing_updates():
                    nonlocal local_pts, local_seq
                    difference = await listener_client(GetDifferenceRequest(
                        pts=local_pts,
                        pts_total_limit=100,
                        date=0,
                        qts=0
                    ))
                    for update in difference.new_messages:
                        await handle_new_message_update(update)
                    local_pts = difference.state.pts
                    local_seq = difference.state.seq




                async def start_live_cloner(listener_client, source_entity):
                    @listener_client.on(events.NewMessage(chats=source_entity, incoming=True))
                    async def event_handler(event):
                        try:
                            await handle_new_message(event)
                        except Exception as e:
                            print(Style.BRIGHT + Fore.YELLOW + f"Error handling new message: {e}. Retrying in 3 seconds...")
                            await asyncio.sleep(3)

                        try:
                            await handle_new_message_update(event.message)
                        except Exception as e:
                            print(Style.BRIGHT + Fore.YELLOW + f"Error in handling update: {e}. Retrying in 5 seconds...")
                            await asyncio.sleep(5)

                    print(Style.BRIGHT + Fore.GREEN + "LIVE CLONER IS " + Style.BRIGHT + Fore.RED + " LIVE:" + Style.BRIGHT + Fore.GREEN + " Listening for new messages...")

                    # Timeout logic: Automatically stop after 30 seconds
                    try:
                        await asyncio.wait_for(listener_client.run_until_disconnected())
                    except asyncio.TimeoutError:
                        print(Style.BRIGHT + Fore.RED + "Timeout reached, stopping live cloner...")
                    except Exception as e:
                        print(Style.BRIGHT + Fore.RED + f"Error: {e}")
                    finally:
                        await listener_client.disconnect()
                        print(Style.BRIGHT + Fore.RED + "Live cloner project stopped successfully!")

                # Usage
                try:
                    await start_live_cloner(listener_client, source_entity)
                except Exception as e:
                    print(Style.BRIGHT + Fore.RED + f"Critical error: {e}")
                    try:
                        await listener_client.disconnect()
                    except Exception as disconnect_error:
                        print(f"Error disconnecting: {disconnect_error}")


            except Exception as e:
                print(Style.BRIGHT + Fore.RED +f"Critical error: {e}")
                print(e)
                try:
                    await listener_client.disconnect()
                except:
                    pass
                text__string_to_send = Style.BRIGHT + Fore.RED +'Listener Account Connected but Error occured due to'+str(e)+" \n Project Stopped!"
                return None
            finally:
                try:
                    await listener_client.disconnect()
                except:
                    pass
                    return None

            
        else:
            print(Style.BRIGHT + Fore.RED +f"Listener {listener_phone}Not connected!")
            try:
                await listener_client.disconnect()
            except:
                pass
            print(Style.BRIGHT + Fore.RED +f"The Telegram Account  {listener_phone} is not logged in\nPlease Re-login the account! Project Stopped!")
            return None

        print(Style.BRIGHT + Fore.RED +"live cloner project Stopped Successfully!")
        return None



    print(Style.BRIGHT + Fore.BLUE+"Please wait...")

    Listener_status=await check_if_listener_is_logged_in(listener_account_phone_txt)
    source_group_status=None
    destination_group_status=None
    try:
        with open(livesettings_source_group_file_path, 'r') as file:
            source_group_status = file.read()
        with open(livesettings_destination_group_file_path, 'r') as file:
            destination_group_status = file.read()
    except:
        source_group_status="Error"
        destination_group_status="Error"

    phone_numbers_count = count_lines_in_file(sessions_phone_file)

    colorama.init(autoreset=True)

    print(Style.BRIGHT + Fore.GREEN + '                 [1] '+Style.BRIGHT + Fore.MAGENTA+'Login Listener ('+str(Listener_status)+Style.BRIGHT + Fore.MAGENTA+")")
    print(Style.BRIGHT + Fore.GREEN + '                 [2] '+Style.BRIGHT + Fore.CYAN+'Source Group ('+Style.BRIGHT + Fore.BLUE+str(source_group_status)+Style.BRIGHT + Fore.CYAN+")")
    print(Style.BRIGHT + Fore.GREEN + '                 [3] '+Style.BRIGHT + Fore.CYAN+'Destination Group ('+Style.BRIGHT + Fore.BLUE+str(destination_group_status)+Style.BRIGHT + Fore.CYAN+")")
    print(Style.BRIGHT + Fore.GREEN + '                 [4] '+Style.BRIGHT + Fore.YELLOW+'Optional Settings')
    print(Style.BRIGHT + Fore.GREEN + '                 [5] '+Style.BRIGHT + Fore.CYAN+'Join Destination with all sessions')
    print(Style.BRIGHT + Fore.GREEN + '                 [6] '+Style.BRIGHT + Fore.GREEN+'RUN LIVE CLONER')
    print(Style.BRIGHT + Fore.RED+ '                 [0]'+Style.BRIGHT + Fore.RED+' Back to Menu]')
    TeleChoice = (input(Style.BRIGHT + Fore.BLUE +'\nEnter your choice: '))

    try:
        TeleChoice=int(TeleChoice)
    except Exception as e:
        print("Error Occurred!\n",e)
        await Manage_Live_Cloner_Function()
    if TeleChoice==1:
        await login_acc_menu()     
    elif TeleChoice==2:
        await set_source_group(listener_account_phone_txt,listener_account_session_folder,livesettings_source_group_file_path,Manage_Live_Cloner_Function())
    elif TeleChoice==3:
        await set_destination_group(livesettings_destination_group_file_path,Manage_Live_Cloner_Function())
    elif TeleChoice==4:
        await update_and_display_settings(livesettings_file_path,Manage_Live_Cloner_Function())
    elif TeleChoice==5:
        await group_and_channel_joiner(livesettings_destination_group_file_path,Manage_Live_Cloner_Function())
    elif TeleChoice==6:
        async def run_cloner():
            while True:
                try:
                    print("Running Live_Cloner_Running_Function()...")
                    await Live_Cloner_Running_Function()  # Run your cloner function
                except Exception as e:
                    print(f"Cloner crashed due to: {e}")
                finally:
                    print("Restarting...")
                    time.sleep(5)  # Optional delay before restarting

        # Call the function to start the process
        await run_cloner()
    elif TeleChoice==0:
                await alex_main_menu()
        
    else:
        print(Style.BRIGHT + Fore.RED +'\nInvalid Input!')
        await Manage_Live_Cloner_Function()






async def alex_main_menu():
    print_section_title("AlexChat - Telegram Fake Chats")   

    phone_numbers_count = count_lines_in_file(sessions_phone_file)

    print(Style.BRIGHT + Fore.GREEN + '                 [1] '+Style.BRIGHT + Fore.GREEN+'Manage Accounts/Sessions ('+Style.BRIGHT + Fore.YELLOW+str(phone_numbers_count)+Style.BRIGHT + Fore.GREEN+" Phones)")
    print(Style.BRIGHT + Fore.GREEN+ '                 [2] '+Style.BRIGHT + Fore.BLUE +'Chats Scraper')
    print(Style.BRIGHT + Fore.GREEN+ '                 [3] '+Style.BRIGHT + Fore.BLUE +'Fake/Custom Chats')
    print(Style.BRIGHT + Fore.GREEN + '                 [4] '+Style.BRIGHT + Fore.BLUE+'Live Chat Cloner')
    print(Style.BRIGHT + Fore.RED + '                 [0] '+Style.BRIGHT + Fore.RED +'Quit')
    TeleChoice = (input(Style.BRIGHT + Fore.BLUE +'\nEnter your choice: '))

    try:
        TeleChoice=int(TeleChoice)
    except Exception as e:
        print("Error Occurred!\n",e)
        await alex_main_menu()
    if TeleChoice==1:
       await accounts_manager(alex_main_menu())

    elif TeleChoice==2:
       await chat_scraper_main_menu()
    elif TeleChoice==3:
        await fake_custom_chat_main_menu()
    elif TeleChoice==4:

        await Manage_Live_Cloner_Function()
    elif TeleChoice==0:
        x=input("Quitting! Press Enter to Quit!")
        quit()
    else:
        print(Style.BRIGHT + Fore.RED +'\nInvalid Input!')
        await alex_main_menu()







# Removed redundant imports, added all required at the beginning for cleaner code
# Removed banner function comments and initialization moved to the function definition block.

def banner():

    print(Style.BRIGHT + Fore.RED+ '..................................................................')
    print(Style.BRIGHT + Fore.GREEN+ '\nSoftware Developed by: '+Style.BRIGHT + Fore.GREEN+ str(software_developer_contact))
    print(Style.BRIGHT + Fore.RED + "I do not take any responsibility for anything you do using this script\nUsing this software might be illegal in your country\nUse it at your own risk!")
    print(Style.BRIGHT + Fore.GREEN + '\nLoading...')



    def display_loading_message(message, delay=0.01):
        for char in message:
            sys.stdout.write(char)
            sys.stdout.flush()
            time.sleep(delay)

    display_loading_message('Loading.')
    display_loading_message('.' * 56 + '100%\n')
    time.sleep(0.2)

    print(software_developer_contact + "\n")
    
    try:
        rk = requests.get(software_version_pastebin_link)
        latest_version = float(rk.text)
        
        if latest_version <= alexchat_version:
            print(Style.BRIGHT + Fore.BLUE + f"Your software is up to date. v.{alexchat_version}")
        else:
            print(Style.BRIGHT + Fore.RED + f"Please update your software to v.{latest_version}")
    except:
        print("Unable to Connect to TeleDragon Update Server")

def main_menu():
    def get_internet_datetime(time_zone="etc/utc"):
        timeapi_url = "https://www.timeapi.io/api/Time/current/zone"
        try:
            request = requests.get(timeapi_url, params={"timeZone": time_zone})
            r_dict = request.json()
            return datetime.datetime(
                year=r_dict["year"], month=r_dict["month"], day=r_dict["day"],
                hour=r_dict["hour"], minute=r_dict["minute"], second=r_dict["seconds"],
                microsecond=r_dict["milliSeconds"] * 1000
            )
        except:
            return None

    def get_decode_key():
        try:
            r = requests.get(Decode_key_pastebin_link)
            return r.text
        except:
            return "ts2IgVkgxAcs3uspkUfAVb7rVA6zqlGG5DpyyVTWri0="

    def get_encoded_machine_id():
        machine_id_string = platform.node()
        license_key = hashlib.sha256(machine_id_string.encode()).hexdigest()[:36]
        return license_key

    def encode_key(text_to_encode, key):
        fernet = Fernet(bytes(key, 'utf-8'))
        return fernet.encrypt(text_to_encode)

    def decode_key(text_to_decode, key):
        fernet = Fernet(bytes(key, 'utf-8'))
        return fernet.decrypt(text_to_decode)

    def is_program_expired():
        if not os.path.exists(license_filepath):
            display_license_issue("No license Found!")
            return
        
        with open(license_filepath, 'r') as file:
            encoded_license = file.read().strip()
        
        if not encoded_license:
            display_license_issue("No license Found!")
            return
        
        try:
            decoded_key = get_decode_key()
            decoded_license = decode_key(encoded_license, decoded_key).decode('utf-8')
            license_data = decoded_license.split()
            
            machine_id, start_date, _, duration = license_data
            start_date = datetime.datetime.strptime(start_date, '%Y-%m-%d')
            expire_date = start_date + datetime.timedelta(days=int(duration))
            
            if machine_id != get_encoded_machine_id():
                display_license_issue("Invalid license Found.")
                return
            
            if datetime.datetime.now() > expire_date:
                banner()
                print(Style.BRIGHT + Fore.RED + f"License expired on: {expire_date.strftime('%b %d %Y')}")
            else:
                print(Style.BRIGHT + Fore.GREEN + "License is valid.")
                asyncio.run(alex_main_menu())

        except:
            display_license_issue("Invalid License Found!")

    def display_license_issue(issue_message):
        banner()
        machine_id = get_encoded_machine_id()
        print(Style.BRIGHT + Fore.RED + issue_message)
        print("\nYour Device ID: " + Style.BRIGHT + Fore.GREEN + machine_id)
        license_key = input('Paste License Key here: ').strip()
        
        with open(license_filepath, "w") as f:
            f.write(license_key)
        
        print(Style.BRIGHT + Fore.WHITE + "\nLicense Saved Successfully. Restart Program to activate.")
        exit()

    is_program_expired()

main_menu()
