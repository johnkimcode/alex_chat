import os

def install_package(package_name):
    """Install the specified package using pip."""
    print(f"\nREQUIREMENTS: INSTALLING - {package_name.upper()}... Please wait")
    os.system(f'pip3 install {package_name}')
    os.system('cls' if os.name == 'nt' else 'clear')

# Clear screen and start installation
os.system('cls' if os.name == 'nt' else 'clear')
print("\nINSTALLING REQUIRED MODULES...\n")

# Ensure pip is up-to-date
os.system('python -m pip3 install --upgrade pip')

# Define required packages
packages = [
    'colorama', 'python-cfonts', 'telethon', 'requests', 'termcolor',
    'pyfiglet', 'pyrogram', 'pysocks', 'cryptography', 'TgCrypto',
    'async-timeout', 'python-socks', 'tqdm', 'emoji', 'demoji'
]

# Install required packages
for package in packages:
    install_package(package)

# Notify the user of completion
print("\n" + "REQUIREMENTS INSTALLED SUCCESSFULLY!")
input("[+] Now run your main script (e.g., Main.py)")
